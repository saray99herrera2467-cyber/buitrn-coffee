import React, { useState } from 'react';
import axios from 'axios';

const VerificacionEmail = ({ email, onVerificado, onCancelar }) => {
  const [codigo, setCodigo] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [cargando, setCargando] = useState(false);
  const [intentos, setIntentos] = useState(0);

  const API_URL = 'http://localhost:3001/api/verificacion';

  const handleVerificar = async (e) => {
    e.preventDefault();
    if (!codigo || codigo.length !== 6) {
      setMensaje('❌ Ingresa el código de 6 dígitos');
      return;
    }

    setCargando(true);
    setMensaje('');

    try {
      const response = await axios.post(`${API_URL}/verificar-codigo`, {
        Correo: email,
        Codigo: codigo
      });

      if (response.data.success) {
        setMensaje('✅ ' + response.data.message);
        if (onVerificado) {
          setTimeout(() => onVerificado(), 1500);
        }
      }
    } catch (error) {
      setMensaje('❌ ' + (error.response?.data?.message || 'Error al verificar'));
      setIntentos(prev => prev + 1);
    } finally {
      setCargando(false);
    }
  };

  const handleReenviar = async () => {
    setCargando(true);
    setMensaje('');

    try {
      const response = await axios.post(`${API_URL}/reenviar-codigo`, {
        Correo: email
      });

      if (response.data.success) {
        setMensaje('✅ ' + response.data.message);
      }
    } catch (error) {
      setMensaje('❌ ' + (error.response?.data?.message || 'Error al reenviar'));
    } finally {
      setCargando(false);
    }
  };

  return (
    <div className="verificacion-container">
      <h3> Verifica tu correo</h3>
      <p>Hemos enviado un código de 6 dígitos a <strong>{email}</strong></p>
      
      <form onSubmit={handleVerificar}>
        <div className="form-group">
          <label>Código de verificación</label>
          <input
            type="text"
            value={codigo}
            onChange={(e) => setCodigo(e.target.value.replace(/\D/g, '').slice(0, 6))}
            placeholder="000000"
            maxLength="6"
            autoFocus
          />
        </div>
        
        {mensaje && (
          <div className={`mensaje ${mensaje.includes('✅') ? 'exito' : 'error'}`}>
            {mensaje}
          </div>
        )}
        
        <div className="verificacion-buttons">
          <button type="submit" disabled={cargando}>
            {cargando ? 'Verificando...' : 'Verificar'}
          </button>
          <button type="button" className="btn-secundario" onClick={handleReenviar} disabled={cargando}>
            Reenviar código
          </button>
          <button type="button" className="btn-cancelar" onClick={onCancelar} disabled={cargando}>
            Cancelar
          </button>
        </div>
      </form>
      
      <p className="verificacion-info">
         El código expira en 3 minutos • {5 - intentos} intentos restantes
      </p>
    </div>
  );
};

export default VerificacionEmail;