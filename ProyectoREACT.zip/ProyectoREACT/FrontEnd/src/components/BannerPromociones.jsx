// src/components/BannerPromociones.jsx
import React, { useState, useEffect } from 'react';
import { promocionesService } from '../services/promociones';
import '../estilos/BannerPromociones.css';

const BannerPromociones = () => {
  const [promociones, setPromociones] = useState([]);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    console.log('🔄 BannerPromociones - Componente montado');
    cargarPromociones();
  }, []);

  const cargarPromociones = async () => {
    console.log('📦 Iniciando carga de promociones...');
    try {
      const data = await promocionesService.getPromocionesActivas();
      console.log('📊 Datos recibidos:', data);
      console.log('📊 Cantidad de promociones:', data.length);
      setPromociones(data);
      setCargando(false);
    } catch (error) {
      console.error('❌ Error al cargar promociones:', error);
      setCargando(false);
    }
  };

  console.log('🎯 Estado actual - cargando:', cargando, 'promociones:', promociones.length);

  if (cargando) {
    console.log('⏳ Mostrando loading...');
    return <div style={{ padding: '20px', textAlign: 'center', background: '#f0f0f0' }}>Cargando promociones...</div>;
  }

  if (promociones.length === 0) {
    console.log('📭 No hay promociones activas');
    return <div style={{ padding: '20px', textAlign: 'center', background: '#fff3cd' }}>📢 No hay promociones disponibles</div>;
  }

  console.log('🎉 Mostrando banner con', promociones.length, 'promociones');

  return (
    <div className="banner-promociones">
      <div className="banner-container">
        <div className="banner-header">
          <span className="banner-icon">🎉</span>
          <h2>Promociones Especiales</h2>
        </div>
        <div className="banner-grid">
          {promociones.slice(0, 4).map((promo) => (
            <div key={promo.ID_Promocion} className="banner-card">
              <div className="banner-card-content">
                <div className="banner-card-icon">
                  {promo.Tipo === 'descuento_porcentaje' && '🔥'}
                  {promo.Tipo === 'descuento_fijo' && '💰'}
                  {promo.Tipo === '2x1' && '🎁'}
                  {promo.Tipo === 'puntos_dobles' && '⭐'}
                  {promo.Tipo === 'combo' && '📦'}
                </div>
                <div>
                  <h3>{promo.Nombre}</h3>
                  <p className="banner-descripcion">{promo.Descripcion}</p>
                  <p className="banner-tipo">{getTipoLabel(promo.Tipo, promo.Valor)}</p>
                  {promo.Producto_Nombre && (
                    <p className="banner-producto">📌 {promo.Producto_Nombre}</p>
                  )}
                  {promo.Minimo_Compra && (
                    <p className="banner-minimo">💰 Mínimo: ${promo.Minimo_Compra.toLocaleString()}</p>
                  )}
                  <p className="banner-fecha">
                    ⏳ Válido hasta: {new Date(promo.Fecha_Fin).toLocaleDateString('es-CO')}
                  </p>
                  {promo.Codigo && (
                    <div className="banner-codigo">
                      <span>Código: </span>
                      <strong>{promo.Codigo}</strong>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const getTipoLabel = (tipo, valor) => {
  const tipos = {
    'descuento_porcentaje': `🎯 ${valor}% de descuento`,
    'descuento_fijo': `💰 $${valor?.toLocaleString()} de descuento`,
    '2x1': '🎁 2x1',
    'puntos_dobles': '⭐ Puntos Dobles',
    'combo': '📦 Combo Especial'
  };
  return tipos[tipo] || tipo;
};

export default BannerPromociones;