// src/components/PromocionCarrito.jsx
import React, { useState } from 'react';
import { promocionesService } from '../services/promociones';
import '../estilos/PromocionCarrito.css';

const PromocionCarrito = ({ subtotal, items, onPromocionAplicada }) => {
  const [codigo, setCodigo] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [cargando, setCargando] = useState(false);
  const [promocionAplicada, setPromocionAplicada] = useState(null);

  const token = localStorage.getItem('token');

  const handleAplicarPromocion = async () => {
    if (!codigo.trim()) {
      setMensaje('⚠️ Ingresa un código de promoción');
      return;
    }

    setCargando(true);
    setMensaje('');

    try {
      const result = await promocionesService.aplicarPromocion(
        codigo,
        subtotal,
        items,
        token
      );

      if (result.success) {
        setMensaje(`✅ ${result.data.mensaje}`);
        setPromocionAplicada(result.data);
        if (onPromocionAplicada) {
          onPromocionAplicada(result.data);
        }
      } else {
        setMensaje(`❌ ${result.message}`);
        if (onPromocionAplicada) {
          onPromocionAplicada(null);
        }
      }
    } catch (error) {
      setMensaje('❌ Error al aplicar la promoción');
      if (onPromocionAplicada) {
        onPromocionAplicada(null);
      }
    } finally {
      setCargando(false);
    }
  };

  const handleQuitarPromocion = () => {
    setPromocionAplicada(null);
    setCodigo('');
    setMensaje('');
    if (onPromocionAplicada) {
      onPromocionAplicada(null);
    }
  };

  if (promocionAplicada) {
    return (
      <div className="promocion-aplicada">
        <div className="promocion-info">
          <span className="promocion-icon">🎉</span>
          <div>
            <p className="promocion-nombre">{promocionAplicada.promocion.Nombre}</p>
            {promocionAplicada.descuento > 0 && (
              <p className="promocion-descuento">
                Descuento: ${promocionAplicada.descuento.toLocaleString()}
              </p>
            )}
            <p className="promocion-mensaje">{promocionAplicada.mensaje}</p>
          </div>
        </div>
        <button onClick={handleQuitarPromocion} className="btn-quitar-promocion">
          ❌ Quitar
        </button>
      </div>
    );
  }

  return (
    <div className="promocion-carrito">
      <div className="promocion-input">
        <input
          type="text"
          placeholder="📦 Código de promoción"
          value={codigo}
          onChange={(e) => setCodigo(e.target.value.toUpperCase())}
          disabled={cargando}
        />
        <button 
          onClick={handleAplicarPromocion} 
          disabled={cargando}
          className="btn-aplicar"
        >
          {cargando ? '⏳' : 'Aplicar'}
        </button>
      </div>
      {mensaje && (
        <p className={`mensaje-promocion ${mensaje.includes('✅') ? 'exito' : 'error'}`}>
          {mensaje}
        </p>
      )}
    </div>
  );
};

export default PromocionCarrito;