import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../estilos/resenas.css';

const ResenasProducto = ({ productoId, onCalificacionActualizada }) => {
  const [resenas, setResenas] = useState([]);
  const [promedio, setPromedio] = useState({ promedio: 0, total: 0 });
  const [cargando, setCargando] = useState(true);
  const [usuario, setUsuario] = useState(null);
  const [formData, setFormData] = useState({ calificacion: 5, comentario: '' });
  const [enviando, setEnviando] = useState(false);
  const [mensaje, setMensaje] = useState('');

  const API_URL = 'http://localhost:3001';

  useEffect(() => {
    const user = localStorage.getItem('usuario');
    if (user) setUsuario(JSON.parse(user));
    cargarResenas();
    cargarPromedio();
  }, [productoId]);

  const cargarResenas = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/resenas/producto/${productoId}`);
      setResenas(response.data);
      setCargando(false);
    } catch (err) {
      console.error(' Error al cargar reseñas:', err);
      setCargando(false);
    }
  };

  const cargarPromedio = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/resenas/producto/${productoId}/promedio`);
      
      const data = response.data || { promedio: 0, total: 0 };
      const promedioNumero = typeof data.promedio === 'number' ? data.promedio : 0;
      const totalNumero = typeof data.total === 'number' ? data.total : 0;
      
      setPromedio({ 
        promedio: promedioNumero, 
        total: totalNumero 
      });
      
      if (onCalificacionActualizada) {
        onCalificacionActualizada(promedioNumero, totalNumero);
      }
    } catch (err) {
      console.error(' Error al cargar promedio:', err);
      setPromedio({ promedio: 0, total: 0 });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!usuario) {
      setMensaje(' Debes iniciar sesión para dejar una reseña');
      setTimeout(() => setMensaje(''), 3000);
      return;
    }

    if (!formData.comentario.trim()) {
      setMensaje(' Por favor escribe un comentario');
      return;
    }

    setEnviando(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(`${API_URL}/api/resenas`,
        { 
          producto_id: productoId, 
          calificacion: parseInt(formData.calificacion), 
          comentario: formData.comentario 
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMensaje(' Reseña enviada correctamente. Espera aprobación.');
      setFormData({ calificacion: 5, comentario: '' });
      cargarResenas();
      cargarPromedio();
      setTimeout(() => setMensaje(''), 3000);
    } catch (err) {
      setMensaje(err.response?.data?.message || ' Error al enviar la reseña');
    } finally {
      setEnviando(false);
    }
  };

  // 🔥 CORREGIDO: Renderizar estrellas con validación
  const renderEstrellas = (calificacion, size = 'normal') => {
    const num = typeof calificacion === 'number' ? calificacion : 0;
    const redondeado = Math.round(num);
    const estrellas = [];
    
    for (let i = 1; i <= 5; i++) {
      estrellas.push(
        <span 
          key={i} 
          className={i <= redondeado ? 'estrella-llena' : 'estrella-vacia'}
          style={{
            fontSize: size === 'grande' ? '24px' : '18px',
            color: i <= redondeado ? '#f5a623' : '#ddd'
          }}
        >
          ★
        </span>
      );
    }
    return estrellas;
  };

  const formatearPromedio = (valor) => {
    const num = Number(valor);
    if (!isNaN(num) && num > 0) {
      return num.toFixed(1);
    }
    return "0.0";
  };

  const formatFecha = (fecha) => {
    if (!fecha) return 'Fecha no disponible';
    return new Date(fecha).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (cargando) {
    return (
      <div className="resenas-container">
        <div className="loading">Cargando reseñas...</div>
      </div>
    );
  }

  return (
    <div className="resenas-container">
      <div className="resenas-header">
        <h3> Opiniones de clientes</h3>
        <div className="promedio-container">
          <div className="estrellas-promedio">
            {renderEstrellas(promedio.promedio, 'grande')}
          </div>
          <span className="promedio-numero">
            {formatearPromedio(promedio.promedio)}
          </span>
          <span className="total-resenas">
            ({promedio.total} {promedio.total === 1 ? 'reseña' : 'reseñas'})
          </span>
        </div>
      </div>

      <div className="agregar-resena">
        <h4>Deja tu opinión</h4>
        {mensaje && (
          <div className={`mensaje-resena ${mensaje.includes('✅') ? 'exito' : 'error'}`}>
            {mensaje}
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="calificacion-input">
            <label>Calificación:</label>
            <select 
              name="calificacion" 
              value={formData.calificacion} 
              onChange={(e) => setFormData({...formData, calificacion: e.target.value})}
              disabled={!usuario}
            >
              <option value="5">⭐ 5 estrellas - Excelente</option>
              <option value="4">⭐ 4 estrellas - Muy bueno</option>
              <option value="3">⭐ 3 estrellas - Bueno</option>
              <option value="2">⭐ 2 estrellas - Regular</option>
              <option value="1">⭐ 1 estrella - Malo</option>
            </select>
          </div>
          <div className="comentario-input">
            <label>Comentario:</label>
            <textarea 
              name="comentario" 
              value={formData.comentario} 
              onChange={(e) => setFormData({...formData, comentario: e.target.value})} 
              rows="4" 
              placeholder="Cuéntanos tu experiencia..." 
              required 
              disabled={!usuario}
            />
          </div>
          {usuario ? (
            <button type="submit" disabled={enviando}>
              {enviando ? '⏳ Enviando...' : '📝 Enviar reseña'}
            </button>
          ) : (
            <div className="login-para-resenar">
              <p> <a href="/login">Inicia sesión</a> para dejar una reseña</p>
            </div>
          )}
        </form>
      </div>

      <div className="lista-resenas">
        <h4>Reseñas de otros clientes</h4>
        {resenas.length === 0 ? (
          <p className="sin-resenas">🌟 Sé el primero en dejar una reseña</p>
        ) : (
          resenas.map((resena) => (
            <div key={resena.id} className="resena-card">
              <div className="resena-header">
                <strong className="resena-usuario">{resena.nombre_usuario}</strong>
                <div className="resena-estrellas">
                  {renderEstrellas(resena.calificacion)}
                </div>
                <span className="resena-fecha">{formatFecha(resena.fecha)}</span>
              </div>
              <p className="resena-comentario">{resena.comentario}</p>
              {resena.estado === 'pendiente' && (
                <span className="resena-pendiente">⏳ Pendiente de aprobación</span>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ResenasProducto;