import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { promocionesService } from '../services/promociones';
import './estilos-admin/IndexAdmin.css';

const IndexAdmin = () => {
  const navigate = useNavigate();
  const [adminData, setAdminData] = useState(null);
  const [alertas, setAlertas] = useState([]);
  const [productosMasVendidos, setProductosMasVendidos] = useState([]);
  const [productosStockBajo, setProductosStockBajo] = useState([]);
  const [cargandoEstadisticas, setCargandoEstadisticas] = useState(false);
  const [estadoPedidos, setEstadoPedidos] = useState(null);
  const [cargandoPedidos, setCargandoPedidos] = useState(false);
  const [mostrarModalAlertas, setMostrarModalAlertas] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [promocionesActivas, setPromocionesActivas] = useState([]);
  const [cargandoPromociones, setCargandoPromociones] = useState(false);

  const token = localStorage.getItem('token');
  const API_BASE_URL = 'http://localhost:3001/api';

  useEffect(() => {
    const usuarioGuardado = localStorage.getItem('usuario');
    const adminDataGuardado = localStorage.getItem('adminData');
    if (usuarioGuardado) setAdminData(JSON.parse(usuarioGuardado));
    else if (adminDataGuardado) setAdminData(JSON.parse(adminDataGuardado));
    fetchEstadisticas();
    fetchEstadoPedidos();
    fetchAlertasStock();
    fetchPromocionesActivas();
  }, []);

  // =============================================
  //  OBTENER ESTADÍSTICAS DE PRODUCTOS
  // =============================================
  const fetchEstadisticas = async () => {
    setCargandoEstadisticas(true);
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`${API_BASE_URL}/estadisticas/resumen-productos`, {
        headers: { 
          Authorization: `Bearer ${token}`,
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
      });
      
      if (response.data.success) {
        setProductosMasVendidos(response.data.data.productos_mas_vendidos || []);
        setProductosStockBajo(response.data.data.productos_stock_bajo || []);
      }
    } catch (error) {
      console.error('❌ Error al cargar estadísticas:', error);
    } finally {
      setCargandoEstadisticas(false);
    }
  };

  // =============================================
  //  OBTENER ESTADO DE PEDIDOS
  // =============================================
  const fetchEstadoPedidos = async () => {
    setCargandoPedidos(true);
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`${API_BASE_URL}/estadisticas/estado-pedidos`, {
        headers: { 
          Authorization: `Bearer ${token}` 
        }
      });
      
      if (response.data.success) {
        setEstadoPedidos(response.data.data);
      }
    } catch (error) {
      console.error('❌ Error al cargar estado de pedidos:', error);
    } finally {
      setCargandoPedidos(false);
    }
  };

  // =============================================
  //  OBTENER ALERTAS DE STOCK
  // =============================================
  const fetchAlertasStock = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.post(`${API_BASE_URL}/estadisticas/alerta-stock`, {}, {
        headers: { 
          Authorization: `Bearer ${token}` 
        }
      });
      
      if (response.data?.alertas && response.data.alertas.length > 0) {
        setAlertas(response.data.alertas);
        setMostrarModalAlertas(true);
      }
    } catch (error) {
      console.error('❌ Error al cargar alertas de stock:', error);
    }
  };

  // =============================================
  //  OBTENER PROMOCIONES ACTIVAS (NUEVO)
  // =============================================
  const fetchPromocionesActivas = async () => {
    setCargandoPromociones(true);
    const token = localStorage.getItem('token');
    try {
      const data = await promocionesService.getTodasPromociones(token);
      // Filtrar solo las activas
      const activas = data.filter(p => p.Estado === 1 && new Date(p.Fecha_Fin) >= new Date());
      setPromocionesActivas(activas);
    } catch (error) {
      console.error('❌ Error al cargar promociones activas:', error);
    } finally {
      setCargandoPromociones(false);
    }
  };

  // =============================================
  //  NAVEGACIÓN
  // =============================================
  const irA = (ruta) => navigate(ruta);
  
  const cerrarSesion = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminData');
    navigate('/index');
  };

  const getInitials = () => {
    const nombre = adminData ? adminData.Nombre_usuario : 'Administrador';
    return nombre.charAt(0).toUpperCase();
  };

  const cerrarModalAlertas = () => setMostrarModalAlertas(false);

  const getTipoLabel = (tipo, valor) => {
    const tipos = {
      'descuento_porcentaje': `🎯 ${valor}% descuento`,
      'descuento_fijo': `💰 $${valor?.toLocaleString()}`,
      '2x1': '🎁 2x1',
      'puntos_dobles': '⭐ Puntos Dobles',
      'combo': '📦 Combo'
    };
    return tipos[tipo] || tipo;
  };

  const navItems = [
    { label: 'Dashboard', icon: '◈', active: true },
    { label: 'Ver Usuarios', icon: '◉', action: () => irA('/usuarios/ver') },
    { label: 'Inhabilitar Usuarios', icon: '◎', action: () => irA('/usuarios/inhabilitar') },
    { label: 'Cambiar Rol', icon: '◐', action: () => irA('/usuarios/cambiar-rol') },
    { label: 'Crear Producto', icon: '✦', action: () => irA('/productos/crear') },
    { label: 'Ver Productos', icon: '❑', action: () => irA('/productos/ver') },
    { label: 'Actualizar Producto', icon: '↻', action: () => irA('/productos/actualizar') },
    { label: 'Inhabilitar Producto', icon: '⊘', action: () => irA('/productos/inhabilitar') },
    { label: 'PQRS', icon: '◆', action: () => irA('/pqrs/ver') },
    { label: 'Reseñas', icon: '★', action: () => irA('/resenas/ver') },
    { label: 'Pedidos', icon: '▣', action: () => irA('/admin/pedidos') },
    { label: 'Promociones', icon: '🎯', action: () => irA('/promociones/ver') },
  ];

  return (
    <div className={`adm-root ${sidebarCollapsed ? 'sidebar-off' : ''}`}>

      {/* SIDEBAR */}
      <aside className="adm-sidebar">
        <div className="adm-sidebar-top">
          <div className="adm-brand">
            <span className="adm-brand-icon">☕</span>
            {!sidebarCollapsed && <span className="adm-brand-name">Buitrón Coffee</span>}
          </div>
          <button className="adm-collapse-btn" onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>
            {sidebarCollapsed ? '›' : '‹'}
          </button>
        </div>

        <div className="adm-nav-section">
          {!sidebarCollapsed && <span className="adm-nav-label">NAVEGACIÓN</span>}
          {navItems.map((item, i) => (
            <button
              key={i}
              className={`adm-nav-item ${item.active ? 'active' : ''}`}
              onClick={item.action}
              title={sidebarCollapsed ? item.label : ''}
            >
              <span className="adm-nav-icon">{item.icon}</span>
              {!sidebarCollapsed && <span className="adm-nav-text">{item.label}</span>}
            </button>
          ))}
        </div>

        <div className="adm-sidebar-bottom">
          <div className="adm-user-pill">
            <div className="adm-avatar">{getInitials()}</div>
            {!sidebarCollapsed && (
              <div className="adm-user-info">
                <span className="adm-user-name">{adminData ? adminData.Nombre_usuario : 'Admin'}</span>
                <span className="adm-user-role">Administrador</span>
              </div>
            )}
          </div>
          <button className="adm-logout" onClick={cerrarSesion} title="Cerrar sesión">
            <span>⏻</span>
            {!sidebarCollapsed && <span>Salir</span>}
          </button>
        </div>
      </aside>

      {/* MAIN */}
      <main className="adm-main">

        {/* Topbar */}
        <div className="adm-topbar">
          <div className="adm-topbar-left">
            <h1 className="adm-page-title">Panel de Administración</h1>
            <span className="adm-page-sub">Bienvenido, {adminData ? adminData.Nombre_usuario : 'Admin'}</span>
          </div>
          <div className="adm-topbar-right">
            {alertas.length > 0 && (
              <button className="adm-alert-badge" onClick={() => setMostrarModalAlertas(true)}>
                ⚠️ <span>{alertas.length}</span>
              </button>
            )}
          </div>
        </div>

        {mostrarModalAlertas && alertas.length > 0 && (
          <div className="adm-modal-overlay" onClick={cerrarModalAlertas}>
            <div className="adm-modal" onClick={e => e.stopPropagation()}>
              <div className="adm-modal-head">
                <span className="adm-modal-ico">⚠️</span>
                <h2>Alertas de Stock</h2>
                <button className="adm-modal-close" onClick={cerrarModalAlertas}>✕</button>
              </div>
              <div className="adm-modal-body">
                {alertas.map((alerta, i) => (
                  <div key={i} className="adm-modal-row">
                    <span className="adm-modal-dot"></span>
                    <span>{alerta}</span>
                  </div>
                ))}
              </div>
              <div className="adm-modal-foot">
                <button className="adm-modal-btn" onClick={cerrarModalAlertas}>Entendido</button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================= */}
        {/* 🔥 SECCIÓN DE PROMOCIONES ACTIVAS - NUEVO */}
        {/* ============================================= */}
        <section className="adm-section">
          <div className="adm-section-head">
            <span className="adm-section-ico">🎯</span>
            <h2>Promociones Activas</h2>
            <button 
              className="adm-btn-ver-todas"
              onClick={() => irA('/promociones/ver')}
            >
              Ver todas →
            </button>
          </div>
          
          {cargandoPromociones ? (
            <div className="adm-loading">
              <span className="adm-spinner"></span> Cargando promociones...
            </div>
          ) : promocionesActivas.length === 0 ? (
            <div className="adm-empty-promociones">
              <p>📢 No hay promociones activas actualmente</p>
              <button 
                className="adm-btn-crear"
                onClick={() => irA('/promociones/ver')}
              >
                + Crear promoción
              </button>
            </div>
          ) : (
            <div className="adm-promociones-grid">
              {promocionesActivas.map((promo) => (
                <div key={promo.ID_Promocion} className="adm-promocion-card">
                  <div className="adm-promocion-header">
                    <span className="adm-promocion-icon">
                      {promo.Tipo === 'descuento_porcentaje' && '🔥'}
                      {promo.Tipo === 'descuento_fijo' && '💰'}
                      {promo.Tipo === '2x1' && '🎁'}
                      {promo.Tipo === 'puntos_dobles' && '⭐'}
                      {promo.Tipo === 'combo' && '📦'}
                    </span>
                    <span className="adm-promocion-estado activa">Activa</span>
                  </div>
                  <h4 className="adm-promocion-nombre">{promo.Nombre}</h4>
                  <p className="adm-promocion-descripcion">{promo.Descripcion || 'Sin descripción'}</p>
                  <div className="adm-promocion-detalles">
                    <div className="adm-promocion-detalle">
                      <span>Tipo:</span>
                      <strong>{getTipoLabel(promo.Tipo, promo.Valor)}</strong>
                    </div>
                    {promo.Producto_Nombre && (
                      <div className="adm-promocion-detalle">
                        <span>Producto:</span>
                        <strong>{promo.Producto_Nombre}</strong>
                      </div>
                    )}
                    {promo.Codigo && (
                      <div className="adm-promocion-detalle">
                        <span>Código:</span>
                        <strong className="adm-promocion-codigo">{promo.Codigo}</strong>
                      </div>
                    )}
                    <div className="adm-promocion-detalle">
                      <span>Usos:</span>
                      <strong>{promo.Usos_Actuales || 0} / {promo.Stock_Limite || '∞'}</strong>
                    </div>
                    <div className="adm-promocion-detalle">
                      <span>Válida hasta:</span>
                      <strong>{new Date(promo.Fecha_Fin).toLocaleDateString('es-CO')}</strong>
                    </div>
                  </div>
                  <div className="adm-promocion-footer">
                    <span className="adm-promocion-usos">
                      👥 {promo.Usos_Actuales || 0} usuarios la han usado
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ============================================= */}
        {/* PEDIDOS */}
        {/* ============================================= */}
        <section className="adm-section">
          <div className="adm-section-head">
            <span className="adm-section-ico">▣</span>
            <h2>Estado de Pedidos</h2>
          </div>
          {cargandoPedidos ? (
            <div className="adm-loading">
              <span className="adm-spinner"></span> Cargando datos...
            </div>
          ) : estadoPedidos ? (
            <div className="adm-cards-grid">
              <div className="adm-card">
                <div className="adm-card-head">
                  <span className="adm-card-ico">◈</span>
                  <h3>Resumen General</h3>
                </div>
                <div className="adm-stat-list">
                  <div className="adm-stat-row"><span>Total pedidos</span><strong>{estadoPedidos.totales?.total_pedidos || 0}</strong></div>
                  <div className="adm-stat-row green"><span>Entregados</span><strong>{estadoPedidos.totales?.entregados || 0}</strong></div>
                  <div className="adm-stat-row yellow"><span>Pendientes</span><strong>{estadoPedidos.totales?.pendientes || 0}</strong></div>
                  <div className="adm-stat-row red"><span>Cancelados</span><strong>{estadoPedidos.totales?.cancelados || 0}</strong></div>
                  <div className="adm-stat-row"><span>Ingresos totales</span><strong>${Number(estadoPedidos.totales?.ingresos_totales || 0).toLocaleString()}</strong></div>
                  <div className="adm-stat-row"><span>Ticket promedio</span><strong>${Number(estadoPedidos.totales?.ticket_promedio || 0).toLocaleString()}</strong></div>
                </div>
              </div>
              <div className="adm-card">
                <div className="adm-card-head">
                  <span className="adm-card-ico">◉</span>
                  <h3>Desglose por Estado</h3>
                </div>
                <div className="adm-stat-list">
                  {estadoPedidos.resumen_por_estado?.length > 0 ? (
                    estadoPedidos.resumen_por_estado.map((item, i) => (
                      <div key={i} className="adm-stat-row">
                        <div>
                          <div className="adm-stat-label">{item.Estado}</div>
                          <div className="adm-stat-sub">{item.total_pedidos} pedidos · {item.pagados} pagados</div>
                        </div>
                        <strong>${Number(item.ingresos_totales || 0).toLocaleString()}</strong>
                      </div>
                    ))
                  ) : (
                    <p className="adm-empty">No hay datos disponibles</p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <p className="adm-empty">No se pudieron cargar los datos de pedidos.</p>
          )}
        </section>

        {/* ESTADÍSTICAS */}
        <section className="adm-section">
          <div className="adm-section-head">
            <span className="adm-section-ico">◈</span>
            <h2>Estadísticas del Negocio</h2>
          </div>
          {cargandoEstadisticas ? (
            <div className="adm-loading">
              <span className="adm-spinner"></span> Cargando estadísticas...
            </div>
          ) : (
            <div className="adm-cards-grid">
              <div className="adm-card">
                <div className="adm-card-head">
                  <span className="adm-card-ico gold">🏆</span>
                  <h3>Más Vendidos</h3>
                </div>
                <div className="adm-rank-list">
                  {productosMasVendidos.length === 0 ? (
                    <p className="adm-empty">Sin datos aún</p>
                  ) : (
                    productosMasVendidos.map((p, i) => (
                      <div key={p.ID_Producto} className="adm-rank-row">
                        <span className="adm-rank-num">{i + 1}</span>
                        <div className="adm-rank-info">
                          <span className="adm-rank-name">{p.Nombre_producto}</span>
                          <span className="adm-rank-detail">${Number(p.Precio).toLocaleString()} · {p.TotalVendido} und.</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
              <div className="adm-card adm-card-alert">
                <div className="adm-card-head">
                  <span className="adm-card-ico orange">⚠️</span>
                  <h3>Stock Bajo</h3>
                </div>
                <div className="adm-rank-list">
                  {productosStockBajo.length === 0 ? (
                    <p className="adm-empty adm-ok">✓ Todo en orden</p>
                  ) : (
                    productosStockBajo.map(p => (
                      <div key={p.ID_Producto} className={`adm-stock-row ${p.nivel_stock === 'Crítico - Sin stock' ? 'critico' : 'bajo'}`}>
                        <span className="adm-stock-name">{p.Nombre_producto}</span>
                        <div className="adm-stock-tags">
                          <span className="adm-tag">Stock: {p.Stock}</span>
                          <span className={`adm-tag nivel ${p.nivel_stock === 'Crítico - Sin stock' ? 'critico' : 'bajo'}`}>{p.nivel_stock}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </section>

        {/* ACCIONES RÁPIDAS */}
        <section className="adm-section">
          <div className="adm-section-head">
            <span className="adm-section-ico">✦</span>
            <h2>Acciones Rápidas</h2>
          </div>
          <div className="adm-actions-grid">
            <div className="adm-action-group">
              <h4>Usuarios</h4>
              <div className="adm-action-btns">
                <button className="adm-btn ver" onClick={() => irA('/usuarios/ver')}>Ver</button>
                <button className="adm-btn inhab" onClick={() => irA('/usuarios/inhabilitar')}>Inhabilitar</button>
                <button className="adm-btn rol" onClick={() => irA('/usuarios/cambiar-rol')}>Cambiar Rol</button>
              </div>
            </div>
            <div className="adm-action-group">
              <h4>Productos</h4>
              <div className="adm-action-btns">
                <button className="adm-btn crear" onClick={() => irA('/productos/crear')}>Crear</button>
                <button className="adm-btn ver" onClick={() => irA('/productos/ver')}>Ver</button>
                <button className="adm-btn actualizar" onClick={() => irA('/productos/actualizar')}>Actualizar</button>
                <button className="adm-btn inhab" onClick={() => irA('/productos/inhabilitar')}>Inhabilitar</button>
              </div>
            </div>
            <div className="adm-action-group">
              <h4>Gestión General</h4>
              <div className="adm-action-btns">
                <button className="adm-btn pqrs" onClick={() => irA('/pqrs/ver')}>PQRS</button>
                <button className="adm-btn resenas" onClick={() => irA('/resenas/ver')}>Reseñas</button>
                <button className="adm-btn pedidos" onClick={() => irA('/admin/pedidos')}>Pedidos</button>
                <button className="adm-btn promociones" onClick={() => irA('/promociones/ver')}>Promociones</button>
              </div>
            </div>
          </div>
        </section>

        <footer className="adm-footer">
          © {new Date().getFullYear()} Buitrón Coffee — Panel de Administración
        </footer>
      </main>
    </div>
  );
};

export default IndexAdmin;