import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { promocionesService } from '../services/promociones';
import './estilos-admin/GestionPromociones.css';

const GestionPromociones = () => {
  const navigate = useNavigate();
  const [promociones, setPromociones] = useState([]);
  const [productos, setProductos] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [exito, setExito] = useState('');
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [promocionEditando, setPromocionEditando] = useState(null);

  const token = localStorage.getItem('token');

  const [formData, setFormData] = useState({
    Nombre: '',
    Descripcion: '',
    Tipo: 'descuento_porcentaje',
    Valor: '',
    Codigo: '',
    ID_Producto: '',
    Minimo_Compra: '',
    Fecha_Inicio: '',
    Fecha_Fin: '',
    Stock_Limite: '',
    Estado: 1
  });

  useEffect(() => {
    cargarPromociones();
    cargarProductos();
  }, []);

  const cargarPromociones = async () => {
    try {
      setCargando(true);
      const data = await promocionesService.getTodasPromociones(token);
      setPromociones(data);
      setCargando(false);
    } catch (error) {
      console.error('Error al cargar promociones:', error);
      setError('Error al cargar las promociones');
      setCargando(false);
    }
  };

  const cargarProductos = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/productos/activos');
      const data = await response.json();
      setProductos(data);
    } catch (error) {
      console.error('Error al cargar productos:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setExito('');

    // Validar campos obligatorios
    if (!formData.Nombre || !formData.Tipo || !formData.Fecha_Inicio || !formData.Fecha_Fin) {
      setError('Nombre, Tipo, Fecha Inicio y Fecha Fin son obligatorios');
      return;
    }

    try {
      let result;
      if (promocionEditando) {
        result = await promocionesService.actualizarPromocion(
          promocionEditando.ID_Promocion,
          formData,
          token
        );
      } else {
        result = await promocionesService.crearPromocion(formData, token);
      }

      if (result.success) {
        setExito(result.message);
        setMostrarFormulario(false);
        setPromocionEditando(null);
        resetForm();
        cargarPromociones();
        setTimeout(() => setExito(''), 3000);
      } else {
        setError(result.message);
      }
    } catch (error) {
      setError('Error al guardar la promoción');
    }
  };

  const resetForm = () => {
    setFormData({
      Nombre: '',
      Descripcion: '',
      Tipo: 'descuento_porcentaje',
      Valor: '',
      Codigo: '',
      ID_Producto: '',
      Minimo_Compra: '',
      Fecha_Inicio: '',
      Fecha_Fin: '',
      Stock_Limite: '',
      Estado: 1
    });
  };

  const handleEditar = (promocion) => {
    setPromocionEditando(promocion);
    setFormData({
      Nombre: promocion.Nombre,
      Descripcion: promocion.Descripcion || '',
      Tipo: promocion.Tipo,
      Valor: promocion.Valor || '',
      Codigo: promocion.Codigo || '',
      ID_Producto: promocion.ID_Producto || '',
      Minimo_Compra: promocion.Minimo_Compra || '',
      Fecha_Inicio: promocion.Fecha_Inicio ? new Date(promocion.Fecha_Inicio).toISOString().slice(0, 16) : '',
      Fecha_Fin: promocion.Fecha_Fin ? new Date(promocion.Fecha_Fin).toISOString().slice(0, 16) : '',
      Stock_Limite: promocion.Stock_Limite || '',
      Estado: promocion.Estado
    });
    setMostrarFormulario(true);
  };

  const handleEliminar = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar esta promoción?')) return;

    try {
      const result = await promocionesService.eliminarPromocion(id, token);
      if (result.success) {
        setExito('Promoción eliminada correctamente');
        cargarPromociones();
        setTimeout(() => setExito(''), 3000);
      } else {
        setError(result.message);
      }
    } catch (error) {
      setError('Error al eliminar la promoción');
    }
  };

  const handleCancelar = () => {
    setMostrarFormulario(false);
    setPromocionEditando(null);
    resetForm();
    setError('');
  };

  const getTipoLabel = (tipo) => {
    const tipos = {
      'descuento_porcentaje': '🎯 Descuento Porcentaje',
      'descuento_fijo': '💰 Descuento Fijo',
      '2x1': '🎁 2x1',
      'puntos_dobles': '⭐ Puntos Dobles',
      'combo': '📦 Combo'
    };
    return tipos[tipo] || tipo;
  };

  const getEstadoBadge = (estado, fechaFin) => {
    if (new Date(fechaFin) < new Date()) {
      return <span className="badge-expirada">Expirada</span>;
    }
    if (estado === 1) {
      return <span className="badge-activa">Activa</span>;
    }
    return <span className="badge-inactiva">Inactiva</span>;
  };

  if (cargando) {
    return (
      <div className="gestion-promociones-container">
        <div className="loading">Cargando promociones...</div>
      </div>
    );
  }

  return (
    <div className="gestion-promociones-container">
      <div className="gestion-promociones-header">
        <button className="btn-volver" onClick={() => navigate('/admin')}>
          ← Volver al Panel
        </button>
        <h1>🎯 GESTIÓN DE PROMOCIONES</h1>
        <button 
          className="btn-crear-promocion"
          onClick={() => {
            resetForm();
            setMostrarFormulario(true);
            setPromocionEditando(null);
          }}
        >
          + Nueva Promoción
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}
      {exito && <div className="exito-message">{exito}</div>}

      {/* FORMULARIO DE CREACIÓN/EDICIÓN */}
      {mostrarFormulario && (
        <div className="promocion-form-modal">
          <div className="promocion-form-container">
            <div className="form-header">
              <h2>{promocionEditando ? '✏️ Editar Promoción' : '➕ Nueva Promoción'}</h2>
              <button className="btn-cerrar-form" onClick={handleCancelar}>×</button>
            </div>

            <form onSubmit={handleSubmit} className="promocion-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Nombre *</label>
                  <input
                    type="text"
                    name="Nombre"
                    value={formData.Nombre}
                    onChange={handleInputChange}
                    placeholder="Ej: Descuento 20% en Café Tostado"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Tipo *</label>
                  <select
                    name="Tipo"
                    value={formData.Tipo}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="descuento_porcentaje">🎯 Descuento Porcentaje</option>
                    <option value="descuento_fijo">💰 Descuento Fijo</option>
                    <option value="2x1">🎁 2x1</option>
                    <option value="puntos_dobles">⭐ Puntos Dobles</option>
                    <option value="combo">📦 Combo</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label>Descripción</label>
                <textarea
                  name="Descripcion"
                  value={formData.Descripcion}
                  onChange={handleInputChange}
                  placeholder="Descripción detallada de la promoción..."
                  rows="2"
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Valor</label>
                  <input
                    type="number"
                    name="Valor"
                    value={formData.Valor}
                    onChange={handleInputChange}
                    placeholder="Ej: 20 (para 20%) o 5000 (para $5.000)"
                    step="0.01"
                  />
                  <small>Para descuento porcentaje: valor del %, para descuento fijo: monto en pesos</small>
                </div>
                <div className="form-group">
                  <label>Código (Opcional)</label>
                  <input
                    type="text"
                    name="Codigo"
                    value={formData.Codigo}
                    onChange={handleInputChange}
                    placeholder="Ej: CAFE20"
                    style={{ textTransform: 'uppercase' }}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Producto específico (Opcional)</label>
                  <select
                    name="ID_Producto"
                    value={formData.ID_Producto}
                    onChange={handleInputChange}
                  >
                    <option value="">Todos los productos</option>
                    {productos.map(p => (
                      <option key={p.ID_Producto} value={p.ID_Producto}>
                        {p.Nombre_producto}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>Mínimo de compra (Opcional)</label>
                  <input
                    type="number"
                    name="Minimo_Compra"
                    value={formData.Minimo_Compra}
                    onChange={handleInputChange}
                    placeholder="Ej: 30000"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Fecha Inicio *</label>
                  <input
                    type="datetime-local"
                    name="Fecha_Inicio"
                    value={formData.Fecha_Inicio}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Fecha Fin *</label>
                  <input
                    type="datetime-local"
                    name="Fecha_Fin"
                    value={formData.Fecha_Fin}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Límite de usos (Opcional)</label>
                  <input
                    type="number"
                    name="Stock_Limite"
                    value={formData.Stock_Limite}
                    onChange={handleInputChange}
                    placeholder="Ej: 100"
                  />
                </div>
                <div className="form-group">
                  <label>Estado</label>
                  <select
                    name="Estado"
                    value={formData.Estado}
                    onChange={handleInputChange}
                  >
                    <option value={1}>Activa</option>
                    <option value={0}>Inactiva</option>
                  </select>
                </div>
              </div>

              <div className="form-actions">
                <button type="button" className="btn-cancelar" onClick={handleCancelar}>
                  Cancelar
                </button>
                <button type="submit" className="btn-guardar">
                  {promocionEditando ? 'Actualizar' : 'Crear'} Promoción
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TABLA DE PROMOCIONES */}
      <div className="tabla-container">
        <table className="tabla-promociones">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Tipo</th>
              <th>Producto</th>
              <th>Valor</th>
              <th>Usos</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {promociones.length === 0 ? (
              <tr>
                <td colSpan="8" className="sin-datos">
                  No hay promociones creadas
                </td>
              </tr>
            ) : (
              promociones.map((promo) => (
                <tr key={promo.ID_Promocion}>
                  <td>#{promo.ID_Promocion}</td>
                  <td className="promo-nombre">
                    <strong>{promo.Nombre}</strong>
                    {promo.Descripcion && (
                      <span className="promo-descripcion">{promo.Descripcion}</span>
                    )}
                  </td>
                  <td>{getTipoLabel(promo.Tipo)}</td>
                  <td>{promo.Producto_Nombre || 'Todos'}</td>
                  <td>
                    {promo.Valor ? (
                      promo.Tipo === 'descuento_porcentaje' ? `${promo.Valor}%` : `$${promo.Valor.toLocaleString()}`
                    ) : (
                      '-'
                    )}
                  </td>
                  <td>
                    {promo.Usos_Actuales} / {promo.Stock_Limite || '∞'}
                  </td>
                  <td>{getEstadoBadge(promo.Estado, promo.Fecha_Fin)}</td>
                  <td>
                    <button 
                      className="btn-editar"
                      onClick={() => handleEditar(promo)}
                    >
                      ✏️
                    </button>
                    <button 
                      className="btn-eliminar"
                      onClick={() => handleEliminar(promo.ID_Promocion)}
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default GestionPromociones;