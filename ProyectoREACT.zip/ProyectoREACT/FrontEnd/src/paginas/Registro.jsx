import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import VerificacionEmail from "../components/VerificacionEmail";

function Registro() {
    const navigate = useNavigate();
    const [form, setForm] = useState({
        Nombre_usuario: "",
        Apellido: "",
        Correo: "",
        Documento: "",
        Telefono: "",
        Clave: ""
    });
    const [mensaje, setMensaje] = useState({ texto: "", tipo: "" });
    const [cargando, setCargando] = useState(false);
    const [mostrarVerificacion, setMostrarVerificacion] = useState(false);
    const [emailVerificando, setEmailVerificando] = useState('');
    const [emailVerificado, setEmailVerificado] = useState(false);
    const [enviandoCodigo, setEnviandoCodigo] = useState(false);

    const API_URL = "http://localhost:3001/api";

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
        if (e.target.name === "Correo") {
            setEmailVerificado(false);
            setMostrarVerificacion(false);
        }
    };

    const enviarCodigoVerificacion = async () => {
        const email = form.Correo.trim();
        if (!email || !email.includes('@')) {
            setMensaje({ texto: " Ingresa un correo válido", tipo: "error" });
            return;
        }

        setEnviandoCodigo(true);
        setMensaje({ texto: "", tipo: "" });

        try {
            const response = await axios.post(`${API_URL}/verificacion/enviar-codigo`, {
                Correo: email
            });

            if (response.data.success) {
                setEmailVerificando(email);
                setMostrarVerificacion(true);
                setMensaje({ 
                    texto: response.data.mensaje_correccion || "Código enviado a tu correo", 
                    tipo: "exito" 
                });

                if (response.data.correo_original && response.data.email) {
                    setForm({ ...form, Correo: response.data.email });
                }

                if (response.data.advertencia) {
                    setTimeout(() => {
                        setMensaje({ 
                            texto: response.data.advertencia, 
                            tipo: "advertencia" 
                        });
                    }, 3000);
                }
            }
        } catch (error) {
            const data = error.response?.data;
            let mensajeError = data?.message || "Error al enviar código";
            
            if (data?.correo_sugerido && data?.mensaje_correccion) {
                mensajeError = data.mensaje_correccion;
                setForm({ ...form, Correo: data.correo_sugerido });
            }
            
            setMensaje({ texto: mensajeError, tipo: "error" });
        } finally {
            setEnviandoCodigo(false);
        }
    };

    const handleVerificado = () => {
        setEmailVerificado(true);
        setMostrarVerificacion(false);
        setMensaje({ texto: " Correo verificado correctamente. ¡Ya puedes registrarte!", tipo: "exito" });
    };

    const handleCancelarVerificacion = () => {
        setMostrarVerificacion(false);
        setEmailVerificado(false);
        setMensaje({ texto: " Verificación cancelada", tipo: "error" });
    };

    const registrar = async (e) => {
        e.preventDefault();

        if (!emailVerificado) {
            setMensaje({ 
                texto: " Debes verificar tu correo electrónico antes de registrarte", 
                tipo: "error" 
            });
            return;
        }

        setCargando(true);
        setMensaje({ texto: "", tipo: "" });

        try {
            const datosRegistro = {
                ...form,
                Correo: form.Correo.trim()
            };

            await axios.post(`${API_URL}/auth/register`, datosRegistro);
            
            setMensaje({ 
                texto: "¡Registro exitoso! Redirigiendo al inicio de sesión...", 
                tipo: "exito" 
            });
            
            setForm({
                Nombre_usuario: "",
                Apellido: "",
                Correo: "",
                Documento: "",
                Telefono: "",
                Clave: ""
            });
            
            setTimeout(() => {
                navigate("/login");
            }, 2000);
            
        } catch (err) {
            setMensaje({ 
                texto: err.response?.data?.message || "Error al registrar", 
                tipo: "error" 
            });
        } finally {
            setCargando(false);
        }
    };

    return (
        <div className="auth-body">
            <div className="card">
                <h1>Buitrón Coffee</h1>
                <h2>Crea una Cuenta</h2>

                {mensaje.texto && (
                    <div className={`mensaje-registro ${mensaje.tipo}`}>
                        {mensaje.texto}
                    </div>
                )}

                {!mostrarVerificacion ? (
                    <form onSubmit={registrar}>
                        <label>Nombre</label>
                        <input 
                            name="Nombre_usuario" 
                            placeholder="Nombre" 
                            onChange={handleChange} 
                            value={form.Nombre_usuario} 
                            required 
                        />

                        <label>Apellido</label>
                        <input 
                            name="Apellido" 
                            placeholder="Apellido" 
                            onChange={handleChange} 
                            value={form.Apellido} 
                            required 
                        />

                        <label>Correo</label>
                        <div className="email-verification-group">
                            <input 
                                name="Correo" 
                                type="email"
                                placeholder="Correo electrónico" 
                                onChange={handleChange} 
                                value={form.Correo} 
                                required 
                                disabled={emailVerificado}
                                style={emailVerificado ? { 
                                    borderColor: '#27ae60', 
                                    background: '#f0fff4' 
                                } : {}}
                            />
                            {!emailVerificado && (
                                <button 
                                    type="button" 
                                    className="btn-verificar-email"
                                    onClick={enviarCodigoVerificacion}
                                    disabled={enviandoCodigo}
                                >
                                    {enviandoCodigo ? "⏳" : "Verificar"}
                                </button>
                            )}
                            {emailVerificado && (
                                <span className="email-verificado-badge">
                                    ✅ Verificado
                                </span>
                            )}
                        </div>
                        <label>Documento</label>
                        <input 
                            name="Documento" 
                            placeholder="Documento" 
                            onChange={handleChange} 
                            value={form.Documento} 
                            required 
                        />

                        <label>Teléfono</label>
                        <input 
                            name="Telefono" 
                            placeholder="Teléfono" 
                            onChange={handleChange} 
                            value={form.Telefono} 
                            required 
                        />

                        <label>Contraseña</label>
                        <input 
                            type="password" 
                            name="Clave" 
                            placeholder="Contraseña" 
                            onChange={handleChange} 
                            value={form.Clave} 
                            required 
                        />

                        <button 
                            type="submit" 
                            disabled={cargando || !emailVerificado}
                            style={{
                                opacity: (!emailVerificado || cargando) ? 0.6 : 1,
                                cursor: (!emailVerificado || cargando) ? 'not-allowed' : 'pointer'
                            }}
                        >
                            {cargando ? "Registrando..." : "Registrarse"}
                        </button>

                        {!emailVerificado && (
                            <p style={{ color: '#e74c3c', fontSize: '12px', marginTop: '5px', textAlign: 'center' }}>
                                 Debes verificar tu correo antes de registrarte
                            </p>
                        )}
                    </form>
                ) : (
                    <VerificacionEmail
                        email={emailVerificando}
                        onVerificado={handleVerificado}
                        onCancelar={handleCancelarVerificacion}
                    />
                )}
                
                <div className="links-login">
                    <button className="btn-secundario" onClick={() => navigate("/login")}>
                        ¿Ya tienes cuenta? Inicia sesión
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Registro;