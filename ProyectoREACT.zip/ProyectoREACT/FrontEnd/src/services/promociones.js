const API_URL = 'http://localhost:3001/api/promociones';

export const promocionesService = {
  // Obtener promociones activas (público)
  getPromocionesActivas: async () => {
    try {
      const response = await fetch(`${API_URL}/activas`);
      const data = await response.json();
      return data.success ? data.data : [];
    } catch (error) {
      console.error('Error al obtener promociones:', error);
      return [];
    }
  },

  // Obtener todas las promociones (admin)
  getTodasPromociones: async (token) => {
    try {
      const response = await fetch(`${API_URL}/admin/todas`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      return data.success ? data.data : [];
    } catch (error) {
      console.error('Error al obtener promociones:', error);
      return [];
    }
  },

  // Verificar código promocional
  verificarCodigo: async (codigo) => {
    try {
      const response = await fetch(`${API_URL}/codigo/${codigo}`);
      const data = await response.json();
      return data.success ? data.data : null;
    } catch (error) {
      console.error('Error al verificar código:', error);
      return null;
    }
  },

  // Aplicar promoción al carrito
  aplicarPromocion: async (codigo, subtotal, items, token) => {
    try {
      const response = await fetch(`${API_URL}/aplicar`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ codigo, subtotal, items })
      });
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error al aplicar promoción:', error);
      return { success: false, message: 'Error al aplicar la promoción' };
    }
  },

  crearPromocion: async (promocionData, token) => {
    try {
      const response = await fetch(`${API_URL}/admin/crear`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(promocionData)
      });
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error al crear promoción:', error);
      return { success: false, message: 'Error al crear la promoción' };
    }
  },

  // Actualizar promoción (admin)
  actualizarPromocion: async (id, promocionData, token) => {
    try {
      const response = await fetch(`${API_URL}/admin/actualizar/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(promocionData)
      });
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error al actualizar promoción:', error);
      return { success: false, message: 'Error al actualizar la promoción' };
    }
  },

  // Eliminar promoción (admin)
  eliminarPromocion: async (id, token) => {
    try {
      const response = await fetch(`${API_URL}/admin/eliminar/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error al eliminar promoción:', error);
      return { success: false, message: 'Error al eliminar la promoción' };
    }
  }
};