import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const CarritoContext = createContext();

export const useCarrito = () => {
  const context = useContext(CarritoContext);
  if (!context) {
    throw new Error('useCarrito debe usarse dentro de CarritoProvider');
  }
  return context;
};

export const CarritoProvider = ({ children }) => {
  const [carrito, setCarrito] = useState({ items: [], total: 0 });
  const [cargando, setCargando] = useState(false);

  const token = localStorage.getItem('token');

  const obtenerCarrito = async () => {
    if (!token) return;
    
    console.log("📦 Obteniendo carrito...");
    setCargando(true);
    
    try {
      const res = await axios.get("http://localhost:3001/api/carrito", {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log("✅ Carrito recibido:", res.data);
    
      if (res.data.success) {
        setCarrito({
          items: res.data.data?.items || [],
          total: res.data.data?.total || 0
        });
      } else {
        setCarrito({
          items: res.data.items || [],
          total: res.data.total || 0
        });
      }
    } catch (error) {
      console.error("❌ Error al obtener carrito:", error);
      setCarrito({ items: [], total: 0 });
    } finally {
      setCargando(false);
    }
  };

  const agregarAlCarrito = async (productoId, cantidad = 1) => {
    console.log("🛒 Agregando al carrito:", { productoId, cantidad });

    if (!token) {
      alert("Debes iniciar sesión para agregar productos al carrito");
      return false;
    }

    try {
      const response = await axios.post('http://localhost:3001/api/carrito', {
        productoId,
        cantidad
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      console.log("✅ Respuesta del servidor:", response.data);
      await obtenerCarrito();
      alert("✅ Producto agregado al carrito");
      return true;
    } catch (error) {
      console.error("❌ Error completo:", error);
      console.error("❌ Response:", error.response?.data);
      alert(error.response?.data?.message || "Error al agregar producto al carrito");
      return false;
    }
  };

  const actualizarCantidad = async (itemId, cantidad) => {
    if (!token) return;

    try {
      await axios.put(
        `http://localhost:3001/api/carrito/${itemId}`,
        { cantidad },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      await obtenerCarrito();
    } catch (error) {
      console.error('❌ Error al actualizar cantidad:', error);
      alert(error.response?.data?.message || "Error al actualizar cantidad");
    }
  };

  const eliminarDelCarrito = async (itemId) => {
    if (!token) return;

    try {
      await axios.delete(`http://localhost:3001/api/carrito/${itemId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      await obtenerCarrito();
    } catch (error) {
      console.error('❌ Error al eliminar del carrito:', error);
      alert(error.response?.data?.message || "Error al eliminar producto");
    }
  };

  const vaciarCarrito = async () => {
    console.log("🗑️ Vaciando carrito...");
    
    if (!token) {
      setCarrito({ items: [], total: 0 });
      return true;
    }

    try {
      await axios.delete('http://localhost:3001/api/carrito/vaciar', {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      setCarrito({ items: [], total: 0 });
      console.log("✅ Carrito vaciado correctamente");
      return true;
      
    } catch (error) {
      console.error('❌ Error al vaciar carrito:', error);
      setCarrito({ items: [], total: 0 });
      return false;
    }
  };

  useEffect(() => {
    obtenerCarrito();
  }, [token]);

  return (
    <CarritoContext.Provider value={{
      carrito,
      setCarrito, // 🔥 AGREGAR setCarrito AQUÍ
      cargando,
      agregarAlCarrito,
      actualizarCantidad,
      eliminarDelCarrito,
      vaciarCarrito,
      obtenerCarrito
    }}>
      {children}
    </CarritoContext.Provider>
  );
};