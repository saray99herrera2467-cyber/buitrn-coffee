const express = require("express");
const router = express.Router();
const db = require("../config/db");
const jwt = require("jsonwebtoken");

const SECRET = "secreto123";

// Middleware verificarToken
const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Token requerido" });
  
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: "Token inválido" });
    req.usuarioId = decoded.id;
    next();
  });
};

// Función para actualizar calificación del producto
const actualizarCalificacionProducto = (productoId) => {
  const sql = `
    SELECT AVG(calificacion) as promedio, COUNT(*) as total
    FROM reseñas
    WHERE producto_id = ? AND estado = 'aprobada'
  `;
  
  db.query(sql, [productoId], (err, results) => {
    if (err) {
      console.error("Error al calcular promedio:", err);
      return;
    }
    
    const promedio = results[0].promedio || 0;
    const total = results[0].total || 0;
    
    const updateSql = `
      UPDATE producto 
      SET calificacion_promedio = ?, total_resenas = ?
      WHERE ID_Producto = ?
    `;
    
    db.query(updateSql, [promedio, total, productoId], (err) => {
      if (err) console.error("Error al actualizar producto:", err);
    });
  });
};

/**
 * @swagger
 * tags:
 *   name: Reseñas
 *   description: Calificaciones y reseñas de productos
 */

/**
 * @swagger
 * /resenas/producto/{productoId}:
 *   get:
 *     summary: Obtener reseñas de un producto
 *     description: Devuelve todas las reseñas aprobadas de un producto específico.
 *     tags: [Reseñas]
 *     parameters:
 *       - in: path
 *         name: productoId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del producto
 *     responses:
 *       200:
 *         description: Lista de reseñas
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Resena'
 */
router.get("/producto/:productoId", (req, res) => {
  const { productoId } = req.params;

  const sql = `
    SELECT r.*, u.Nombre_usuario 
    FROM reseñas r
    JOIN usuario u ON r.usuario_id = u.ID_Usuario
    WHERE r.producto_id = ? AND r.estado = 'aprobada'
    ORDER BY r.fecha DESC
  `;

  db.query(sql, [productoId], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

/**
 * @swagger
 * /resenas/producto/{productoId}/promedio:
 *   get:
 *     summary: Obtener promedio de calificaciones
 *     description: Devuelve el promedio y total de reseñas de un producto.
 *     tags: [Reseñas]
 *     parameters:
 *       - in: path
 *         name: productoId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del producto
 *     responses:
 *       200:
 *         description: Promedio de calificaciones
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 promedio:
 *                   type: number
 *                   format: float
 *                 total:
 *                   type: integer
 */
router.get("/producto/:productoId/promedio", (req, res) => {
  const { productoId } = req.params;

  const sql = `
    SELECT AVG(calificacion) as promedio, COUNT(*) as total
    FROM reseñas
    WHERE producto_id = ? AND estado = 'aprobada'
  `;

  db.query(sql, [productoId], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({
      promedio: results[0].promedio || 0,
      total: results[0].total || 0
    });
  });
});

/**
 * @swagger
 * /resenas:
 *   post:
 *     summary: Crear una reseña
 *     description: Crea una nueva reseña para un producto. Requiere autenticación.
 *     tags: [Reseñas]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ResenaCreacion'
 *     responses:
 *       201:
 *         description: Reseña enviada, esperando aprobación
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Reseña enviada, esperando aprobación
 *       400:
 *         description: Datos inválidos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       401:
 *         description: Token inválido
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.post("/", verificarToken, (req, res) => {
  const { producto_id, calificacion, comentario } = req.body;
  const usuario_id = req.usuarioId;

  if (!producto_id || !calificacion || !comentario) {
    return res.status(400).json({ message: "Faltan campos obligatorios" });
  }

  if (calificacion < 1 || calificacion > 5) {
    return res.status(400).json({ message: "La calificación debe ser entre 1 y 5" });
  }

  const checkResenaSql = "SELECT id FROM reseñas WHERE producto_id = ? AND usuario_id = ?";
  db.query(checkResenaSql, [producto_id, usuario_id], (err, resenaResult) => {
    if (err) return res.status(500).json(err);
    if (resenaResult.length > 0) {
      return res.status(400).json({ message: "Ya has reseñado este producto" });
    }

    const getUserSql = "SELECT Nombre_usuario FROM usuario WHERE ID_Usuario = ?";
    db.query(getUserSql, [usuario_id], (err, userResult) => {
      if (err) return res.status(500).json(err);
      
      const nombre_usuario = userResult[0].Nombre_usuario;

      const sql = `
        INSERT INTO reseñas (producto_id, usuario_id, nombre_usuario, calificacion, comentario, estado)
        VALUES (?, ?, ?, ?, ?, 'pendiente')
      `;

      db.query(sql, [producto_id, usuario_id, nombre_usuario, calificacion, comentario], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ message: "Reseña enviada, esperando aprobación" });
      });
    });
  });
});

/**
 * @swagger
 * /resenas/admin:
 *   get:
 *     summary: Obtener todas las reseñas (Admin)
 *     description: Devuelve la lista completa de reseñas del sistema. Solo administradores.
 *     tags: [Reseñas]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de reseñas
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Resena'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/admin", verificarToken, (req, res) => {
  const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
  
  db.query(checkAdminSql, [req.usuarioId], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result[0].ID_Rol !== 1) {
      return res.status(403).json({ message: "No tienes permisos" });
    }

    const sql = `
      SELECT r.*, p.Nombre_producto as producto_nombre
      FROM reseñas r
      JOIN producto p ON r.producto_id = p.ID_Producto
      ORDER BY r.fecha DESC
    `;

    db.query(sql, (err, results) => {
      if (err) return res.status(500).json(err);
      res.json(results);
    });
  });
});

/**
 * @swagger
 * /resenas/admin/{id}:
 *   patch:
 *     summary: Aprobar/Rechazar reseña (Admin)
 *     description: Cambia el estado de una reseña. Solo administradores.
 *     tags: [Reseñas]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID de la reseña
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - estado
 *             properties:
 *               estado:
 *                 type: string
 *                 enum: [pendiente, aprobada, rechazada]
 *     responses:
 *       200:
 *         description: Reseña actualizada correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: Reseña no encontrada
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.patch("/admin/:id", verificarToken, (req, res) => {
  const { id } = req.params;
  const { estado } = req.body;

  const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
  
  db.query(checkAdminSql, [req.usuarioId], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result[0].ID_Rol !== 1) {
      return res.status(403).json({ message: "No tienes permisos" });
    }

    const getProductoSql = "SELECT producto_id FROM reseñas WHERE id = ?";
    db.query(getProductoSql, [id], (err, resenaResult) => {
      if (err) return res.status(500).json(err);
      if (resenaResult.length === 0) {
        return res.status(404).json({ message: "Reseña no encontrada" });
      }
      
      const productoId = resenaResult[0].producto_id;
      
      const sql = "UPDATE reseñas SET estado = ? WHERE id = ?";
      db.query(sql, [estado, id], (err, result) => {
        if (err) return res.status(500).json(err);
        
        actualizarCalificacionProducto(productoId);
        
        res.json({ message: "Reseña actualizada correctamente" });
      });
    });
  });
});

module.exports = router;