const express = require("express");
const router = express.Router();
const db = require("../config/db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { enviarBienvenida, enviarRecuperacionContrasena } = require('../utils/emailService');

// CLAVE JWT 
const SECRET = "secreto123";

/**
 * @swagger
 * tags:
 *   name: Autenticación
 *   description: Endpoints de login, registro y recuperación de contraseña
 */

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Registrar un nuevo usuario
 *     description: Crea una nueva cuenta de usuario. Asigna rol de usuario por defecto (ID_Rol = 2).
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - Nombre_usuario
 *               - Apellido
 *               - Correo
 *               - Clave
 *             properties:
 *               Nombre_usuario:
 *                 type: string
 *                 example: Juan
 *               Apellido:
 *                 type: string
 *                 example: Perez
 *               Correo:
 *                 type: string
 *                 example: juan@mail.com
 *               Documento:
 *                 type: string
 *                 example: 123456789
 *               Telefono:
 *                 type: string
 *                 example: 3001234567
 *               Clave:
 *                 type: string
 *                 example: 123456
 *     responses:
 *       201:
 *         description: Usuario registrado correctamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Usuario registrado correctamente
 *       400:
 *         description: Error en los datos de registro
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: El correo ya está registrado
 *       500:
 *         description: Error interno del servidor
 */
router.post("/register", async (req, res) => {
  const { Nombre_usuario, Apellido, Correo, Documento, Telefono, Clave } = req.body;

  console.log("📝 ========================");
  console.log("📝 INTENTANDO REGISTRAR USUARIO");
  console.log("📝 Datos recibidos:", { Nombre_usuario, Apellido, Correo, Documento, Telefono });
  console.log("📝 ========================");

  // 🔥 Validar campos obligatorios
  if (!Nombre_usuario || !Apellido || !Correo || !Clave) {
    console.log("❌ Campos obligatorios faltantes");
    return res.status(400).json({ 
      message: "Campos obligatorios faltantes: Nombre_usuario, Apellido, Correo, Clave" 
    });
  }

  try {
    // 🔥 VERIFICAR SI EL CORREO YA EXISTE
    const checkSql = "SELECT * FROM usuario WHERE Correo = ?";
    db.query(checkSql, [Correo], async (err, result) => {
      if (err) {
        console.error("❌ Error al verificar correo:", err);
        return res.status(500).json({ 
          message: "Error al verificar correo",
          error: err.message 
        });
      }

      if (result.length > 0) {
        console.log("❌ Correo ya registrado:", Correo);
        return res.status(400).json({ message: "El correo ya está registrado" });
      }

      // 🔥 VERIFICAR SI EL NOMBRE DE USUARIO YA EXISTE
      const checkUserSql = "SELECT * FROM usuario WHERE Nombre_usuario = ?";
      db.query(checkUserSql, [Nombre_usuario], async (err, result) => {
        if (err) {
          console.error("❌ Error al verificar nombre de usuario:", err);
          return res.status(500).json({ 
            message: "Error al verificar nombre de usuario" 
          });
        }

        if (result.length > 0) {
          console.log("❌ Nombre de usuario ya registrado:", Nombre_usuario);
          return res.status(400).json({ message: "El nombre de usuario ya está registrado" });
        }

        try {
          // 🔥 ENCRIPTAR CONTRASEÑA
          const hashedPassword = await bcrypt.hash(Clave, 10);
          console.log("✅ Contraseña encriptada correctamente");

          // 🔥 INSERTAR USUARIO
          // 🔥 NOTA: Si Documento o Telefono no existen en tu tabla, quítalos del INSERT
          const sql = `
            INSERT INTO usuario 
            (Nombre_usuario, Apellido, Correo, Documento, Telefono, Clave, ID_Rol, Estado)
            VALUES (?, ?, ?, ?, ?, ?, 2, 1)
          `;

          console.log("📝 Ejecutando INSERT...");
          console.log("📝 SQL:", sql);
          console.log("📝 Datos:", [Nombre_usuario, Apellido, Correo, Documento || null, Telefono || null, hashedPassword]);

          db.query(
            sql,
            [Nombre_usuario, Apellido, Correo, Documento || null, Telefono || null, hashedPassword],
            async (err, result) => {
              if (err) {
                console.error("❌ Error al insertar usuario:", err);
                console.error("❌ Código de error:", err.code);
                console.error("❌ Mensaje:", err.message);
                
                // 🔥 Mostrar error específico
                if (err.code === 'ER_DUP_ENTRY') {
                  return res.status(400).json({ 
                    message: "Ya existe un usuario con esos datos (documento o teléfono duplicado)" 
                  });
                }
                
                return res.status(500).json({ 
                  message: "Error al registrar usuario",
                  error: err.message,
                  code: err.code
                });
              }

              console.log("✅ Usuario insertado, ID:", result.insertId);

              // 🔥 ENVIAR CORREO DE BIENVENIDA (OPCIONAL - NO DEBE BLOQUEAR)
              try {
                await enviarBienvenida(Correo, Nombre_usuario);
                console.log(`📧 Bienvenida enviada a ${Correo}`);
              } catch (emailError) {
                console.error("❌ Error al enviar bienvenida:", emailError);
                console.error("❌ Detalle del error:", emailError.message);
                // No fallar el registro si el email falla
              }

              res.status(201).json({ 
                message: "✅ Usuario registrado correctamente",
                id: result.insertId
              });
            }
          );
        } catch (hashError) {
          console.error("❌ Error al encriptar contraseña:", hashError);
          res.status(500).json({ 
            message: "Error al procesar la contraseña" 
          });
        }
      });
    });
  } catch (error) {
    console.error("❌ Error en registro:", error);
    res.status(500).json({ 
      message: "Error interno del servidor",
      error: error.message 
    });
  }
});

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Iniciar sesión
 *     description: Autentica a un usuario y devuelve un token JWT.
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - Correo
 *               - Clave
 *             properties:
 *               Correo:
 *                 type: string
 *                 example: admin@buitron.com
 *               Clave:
 *                 type: string
 *                 example: admin123
 *     responses:
 *       200:
 *         description: Login exitoso
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Login exitoso
 *                 token:
 *                   type: string
 *                   example: eyJhbGciOiJIUzI1NiIs...
 *                 usuario:
 *                   type: object
 *                   properties:
 *                     ID_Usuario:
 *                       type: integer
 *                     Nombre_usuario:
 *                       type: string
 *                     Correo:
 *                       type: string
 *                     ID_Rol:
 *                       type: integer
 *       401:
 *         description: Credenciales incorrectas
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Contraseña incorrecta
 */
router.post("/login", (req, res) => {
  const { Correo, Clave } = req.body;

  if (!Correo || !Clave) {
    return res.status(400).json({ message: "Correo y contraseña requeridos" });
  }

  const sql = "SELECT * FROM usuario WHERE Correo = ?";

  db.query(sql, [Correo], async (err, result) => {
    if (err) return res.status(500).json(err);

    if (result.length === 0) {
      return res.status(401).json({ message: "Usuario no existe" });
    }

    const user = result[0];

    // 🔐 Validar contraseña
    const validPassword = await bcrypt.compare(Clave, user.Clave);

    if (!validPassword) {
      return res.status(401).json({ message: "Contraseña incorrecta" });
    }

    if (user.Estado === 0) {
      return res.status(401).json({ message: "Tu cuenta ha sido inhabilitada. Contacta al administrador." });
    }

    // 🎟 Token
    const token = jwt.sign(
      { id: user.ID_Usuario, rol: user.ID_Rol },
      SECRET,
      { expiresIn: "1d" }
    );

    res.json({
      message: "Login exitoso",
      token,
      usuario: {
        ID_Usuario: user.ID_Usuario,
        Nombre_usuario: user.Nombre_usuario,
        Apellido: user.Apellido,
        Correo: user.Correo,
        Documento: user.Documento,
        Telefono: user.Telefono,
        ID_Rol: user.ID_Rol,
        Estado: user.Estado
      }
    });
  });
});

// =========================
// RECUPERACIÓN DE CONTRASEÑA
// =========================
const codigosRecuperacion = new Map();

/**
 * @swagger
 * /auth/olvido-contrasena:
 *   post:
 *     summary: Solicitar recuperación de contraseña
 *     description: Envía un código de verificación al correo del usuario.
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - Correo
 *             properties:
 *               Correo:
 *                 type: string
 *                 example: usuario@mail.com
 *     responses:
 *       200:
 *         description: Código enviado al correo
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Código enviado a tu correo
 *       404:
 *         description: Usuario no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: No existe una cuenta con este correo
 */
router.post("/olvido-contrasena", async (req, res) => {
  const { Correo } = req.body;

  if (!Correo) {
    return res.status(400).json({ message: "El correo es obligatorio" });
  }

  const sql = "SELECT ID_Usuario, Nombre_usuario, Correo FROM usuario WHERE Correo = ? AND Estado = 1";
  
  db.query(sql, [Correo], async (err, result) => {
    if (err) return res.status(500).json(err);
    
    if (result.length === 0) {
      return res.status(404).json({ message: "No existe una cuenta con este correo" });
    }

    const usuario = result[0];
    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    
    codigosRecuperacion.set(usuario.Correo, {
      codigo: codigo,
      expira: Date.now() + 5 * 60 * 1000,
      id_usuario: usuario.ID_Usuario
    });

    try {
      await enviarRecuperacionContrasena(usuario.Correo, usuario.Nombre_usuario, codigo);
      res.json({ message: "Código enviado a tu correo" });
    } catch (error) {
      console.error("Error al enviar correo:", error);
      res.status(500).json({ message: "Error al enviar el correo" });
    }
  });
});

/**
 * @swagger
 * /auth/verificar-codigo:
 *   post:
 *     summary: Verificar código de recuperación
 *     description: Verifica que el código ingresado sea válido.
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - Correo
 *               - codigo
 *             properties:
 *               Correo:
 *                 type: string
 *                 example: usuario@mail.com
 *               codigo:
 *                 type: string
 *                 example: 123456
 *     responses:
 *       200:
 *         description: Código verificado
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Código verificado
 *       400:
 *         description: Código incorrecto o expirado
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Código incorrecto
 */
router.post("/verificar-codigo", (req, res) => {
  const { Correo, codigo } = req.body;
  const registro = codigosRecuperacion.get(Correo);

  if (!registro) {
    return res.status(404).json({ message: "Código no encontrado" });
  }

  if (registro.codigo !== codigo) {
    return res.status(400).json({ message: "Código incorrecto" });
  }

  if (Date.now() > registro.expira) {
    codigosRecuperacion.delete(Correo);
    return res.status(400).json({ message: "Código expirado" });
  }

  res.json({ message: "Código verificado" });
});

/**
 * @swagger
 * /auth/restablecer-contrasena:
 *   post:
 *     summary: Restablecer contraseña
 *     description: Actualiza la contraseña del usuario después de verificar el código.
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - Correo
 *               - codigo
 *               - nuevaClave
 *             properties:
 *               Correo:
 *                 type: string
 *                 example: usuario@mail.com
 *               codigo:
 *                 type: string
 *                 example: 123456
 *               nuevaClave:
 *                 type: string
 *                 example: nueva123456
 *     responses:
 *       200:
 *         description: Contraseña actualizada
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Contraseña actualizada correctamente
 *       400:
 *         description: Código inválido o contraseña muy corta
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: La contraseña debe tener al menos 6 caracteres
 */
router.post("/restablecer-contrasena", async (req, res) => {
  const { Correo, codigo, nuevaClave } = req.body;

  if (nuevaClave.length < 6) {
    return res.status(400).json({ message: "La contraseña debe tener al menos 6 caracteres" });
  }

  const registro = codigosRecuperacion.get(Correo);

  if (!registro || registro.codigo !== codigo) {
    return res.status(400).json({ message: "Código inválido" });
  }

  if (Date.now() > registro.expira) {
    codigosRecuperacion.delete(Correo);
    return res.status(400).json({ message: "Código expirado" });
  }

  const hashedPassword = await bcrypt.hash(nuevaClave, 10);
  const sql = "UPDATE usuario SET Clave = ? WHERE ID_Usuario = ?";
  
  db.query(sql, [hashedPassword, registro.id_usuario], (err, result) => {
    if (err) return res.status(500).json(err);
    
    codigosRecuperacion.delete(Correo);
    res.json({ message: "Contraseña actualizada correctamente" });
  });
});

/**
 * @swagger
 * /auth/perfil:
 *   get:
 *     summary: Obtener perfil del usuario autenticado
 *     description: Devuelve los datos del usuario autenticado mediante el token JWT.
 *     tags: [Autenticación]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Datos del usuario
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 ID_Usuario:
 *                   type: integer
 *                 Nombre_usuario:
 *                   type: string
 *                 Correo:
 *                   type: string
 *       401:
 *         description: Token inválido
 */
router.get("/perfil", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }

    const sql = "SELECT * FROM usuario WHERE ID_Usuario=?";

    db.query(sql, [decoded.id], (err, result) => {
      if (err) return res.status(500).json(err);

      res.json(result[0]);
    });
  });
});

/**
 * @swagger
 * /auth/perfil:
 *   put:
 *     summary: Actualizar perfil del usuario
 *     description: Actualiza los datos del usuario autenticado.
 *     tags: [Autenticación]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               Nombre_usuario:
 *                 type: string
 *               Correo:
 *                 type: string
 *               Documento:
 *                 type: string
 *               Telefono:
 *                 type: string
 *     responses:
 *       200:
 *         description: Usuario actualizado
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Usuario actualizado correctamente
 */
router.put("/perfil", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }

    const { Nombre_usuario, Correo, Documento, Telefono } = req.body;

    const sql = `
      UPDATE usuario
      SET Nombre_usuario=?, Correo=?, Documento=?, Telefono=?
      WHERE ID_Usuario=?
    `;

    db.query(
      sql,
      [Nombre_usuario, Correo, Documento, Telefono, decoded.id],
      (err, result) => {
        if (err) return res.status(500).json(err);

        res.json({ message: "Usuario actualizado correctamente" });
      }
    );
  });
});

/**
 * @swagger
 * /auth/usuarios:
 *   get:
 *     summary: Obtener todos los usuarios (Admin)
 *     description: Devuelve la lista completa de usuarios. Solo administradores.
 *     tags: [Usuarios]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de usuarios
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   ID_Usuario:
 *                     type: integer
 *                   Nombre_usuario:
 *                     type: string
 *                   Correo:
 *                     type: string
 *                   ID_Rol:
 *                     type: integer
 *                   Estado:
 *                     type: integer
 *       403:
 *         description: No tienes permisos
 */
router.get("/usuarios", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }

    const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
    
    db.query(checkAdminSql, [decoded.id], (err, result) => {
      if (err) return res.status(500).json(err);
      
      if (result.length === 0 || result[0].ID_Rol !== 1) {
        return res.status(403).json({ message: "No tienes permisos para ver usuarios" });
      }

      const sql = `
        SELECT u.ID_Usuario, u.Nombre_usuario, u.Apellido, u.Correo, u.Documento, u.Telefono, r.Tipo_rol, u.ID_Rol, u.Estado
        FROM usuario u
        INNER JOIN rol r ON u.ID_Rol = r.ID_Rol
        ORDER BY u.ID_Usuario DESC
      `;
      
      db.query(sql, (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
      });
    });
  });
});

/**
 * @swagger
 * /auth/usuarios/{id}/inhabilitar:
 *   patch:
 *     summary: Inhabilitar usuario (Admin)
 *     description: Cambia el estado del usuario a inhabilitado. Solo administradores.
 *     tags: [Usuarios]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Usuario inhabilitado
 *       403:
 *         description: No tienes permisos
 */
router.patch("/usuarios/:id/inhabilitar", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  const id = req.params.id;

  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }

    const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
    
    db.query(checkAdminSql, [decoded.id], (err, result) => {
      if (err) return res.status(500).json(err);
      
      if (result.length === 0 || result[0].ID_Rol !== 1) {
        return res.status(403).json({ message: "No tienes permisos para inhabilitar usuarios" });
      }

      if (decoded.id == id) {
        return res.status(400).json({ message: "No puedes inhabilitar tu propio usuario" });
      }

      const sql = "UPDATE usuario SET Estado = 0 WHERE ID_Usuario = ?";
      
      db.query(sql, [id], (err, result) => {
        if (err) return res.status(500).json(err);
        
        if (result.affectedRows === 0) {
          return res.status(404).json({ message: "Usuario no encontrado" });
        }
        
        res.json({ message: "Usuario inhabilitado correctamente" });
      });
    });
  });
});

/**
 * @swagger
 * /auth/usuarios/{id}/habilitar:
 *   patch:
 *     summary: Habilitar usuario (Admin)
 *     description: Cambia el estado del usuario a activo. Solo administradores.
 *     tags: [Usuarios]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Usuario habilitado
 *       403:
 *         description: No tienes permisos
 */
router.patch("/usuarios/:id/habilitar", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  const id = req.params.id;

  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }

    const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
    
    db.query(checkAdminSql, [decoded.id], (err, result) => {
      if (err) return res.status(500).json(err);
      
      if (result.length === 0 || result[0].ID_Rol !== 1) {
        return res.status(403).json({ message: "No tienes permisos para habilitar usuarios" });
      }

      const sql = "UPDATE usuario SET Estado = 1 WHERE ID_Usuario = ?";
      
      db.query(sql, [id], (err, result) => {
        if (err) return res.status(500).json(err);
        
        if (result.affectedRows === 0) {
          return res.status(404).json({ message: "Usuario no encontrado" });
        }
        
        res.json({ message: "Usuario habilitado correctamente" });
      });
    });
  });
});

/**
 * @swagger
 * /auth/usuarios/{id}/cambiar-rol:
 *   patch:
 *     summary: Cambiar rol de usuario (Admin)
 *     description: Cambia el rol de un usuario. Solo administradores.
 *     tags: [Usuarios]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - nuevoRol
 *             properties:
 *               nuevoRol:
 *                 type: integer
 *                 enum: [1, 2, 3]
 *     responses:
 *       200:
 *         description: Rol cambiado correctamente
 *       403:
 *         description: No tienes permisos
 */
router.patch("/usuarios/:id/cambiar-rol", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  const id = req.params.id;
  const { nuevoRol } = req.body;

  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }

  if (!nuevoRol || (nuevoRol !== 1 && nuevoRol !== 2 && nuevoRol !== 3)) {
    return res.status(400).json({ message: "Rol inválido. Debe ser 1 (Admin), 2 (Usuario) o 3 (Proveedor)" });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }

    const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
    
    db.query(checkAdminSql, [decoded.id], (err, result) => {
      if (err) return res.status(500).json(err);
      
      if (result.length === 0 || result[0].ID_Rol !== 1) {
        return res.status(403).json({ message: "No tienes permisos para cambiar roles" });
      }

      if (decoded.id == id) {
        return res.status(400).json({ message: "No puedes cambiar tu propio rol" });
      }

      const checkUserSql = "SELECT ID_Usuario, Nombre_usuario FROM usuario WHERE ID_Usuario = ?";
      
      db.query(checkUserSql, [id], (err, result) => {
        if (err) return res.status(500).json(err);
        
        if (result.length === 0) {
          return res.status(404).json({ message: "Usuario no encontrado" });
        }

        const sql = "UPDATE usuario SET ID_Rol = ? WHERE ID_Usuario = ?";
        
        db.query(sql, [nuevoRol, id], (err, result) => {
          if (err) return res.status(500).json(err);
          
          res.json({ 
            message: `Rol cambiado correctamente a ${nuevoRol === 1 ? 'Administrador' : nuevoRol === 2 ? 'Usuario' : 'Proveedor'}`,
            usuario: result[0]
          });
        });
      });
    });
  });
});

// =========================
// 🔵 OBTENER PROVEEDORES (SOLO ADMIN)
// =========================
router.get("/proveedores", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }

    // Verificar que el usuario es administrador
    const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
    
    db.query(checkAdminSql, [decoded.id], (err, result) => {
      if (err) return res.status(500).json(err);
      
      if (result.length === 0 || result[0].ID_Rol !== 1) {
        return res.status(403).json({ message: "No tienes permisos para ver proveedores" });
      }

      // Obtener usuarios con rol de proveedor (ID_Rol = 3)
      const sql = `
        SELECT ID_Usuario, Nombre_usuario, Apellido, Correo, Telefono
        FROM usuario
        WHERE ID_Rol = 3 AND Estado = 1
        ORDER BY Nombre_usuario ASC
      `;
      
      db.query(sql, (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
      });
    });
  });
});

module.exports = router;