const express = require("express");
const router = express.Router();
const db = require("../config/db");
const jwt = require("jsonwebtoken");

const SECRET = "secreto123";

// Middleware verificarToken
const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }
    req.usuarioId = decoded.id;
    req.usuarioRol = decoded.rol;
    next();
  });
};

// =============================================
// ESTADO DE PEDIDOS (Dashboard)
// =============================================
router.get("/estado-pedidos", verificarToken, (req, res) => {
  // Solo administradores
  if (req.usuarioRol !== 1) {
    return res.status(403).json({
      success: false,
      message: "Acceso denegado. Solo administradores."
    });
  }

  const sqlTotales = `
    SELECT 
      COUNT(*) as total_pedidos,
      SUM(CASE WHEN Estado = 'Entregado' THEN 1 ELSE 0 END) as entregados,
      SUM(CASE WHEN Estado = 'Pendiente' THEN 1 ELSE 0 END) as pendientes,
      SUM(CASE WHEN Estado = 'Cancelado' THEN 1 ELSE 0 END) as cancelados,
      SUM(CASE WHEN Estado = 'Entregado' THEN Total ELSE 0 END) as ingresos_totales,
      AVG(CASE WHEN Estado = 'Entregado' THEN Total ELSE NULL END) as ticket_promedio
    FROM pedido
  `;

  db.query(sqlTotales, (err, totales) => {
    if (err) {
      console.error("Error al obtener estado de pedidos:", err);
      return res.status(500).json({
        success: false,
        message: "Error al obtener estado de pedidos"
      });
    }

    const sqlResumen = `
      SELECT 
        Estado,
        COUNT(*) as total_pedidos,
        SUM(Total) as ingresos_totales,
        SUM(CASE WHEN Pagado = 1 THEN 1 ELSE 0 END) as pagados
      FROM pedido
      GROUP BY Estado
      ORDER BY 
        CASE Estado 
          WHEN 'Pendiente' THEN 1 
          WHEN 'Entregado' THEN 2 
          WHEN 'Cancelado' THEN 3 
          ELSE 4 
        END
    `;

    db.query(sqlResumen, (err, resumen) => {
      if (err) {
        console.error("Error al obtener resumen de pedidos:", err);
        return res.status(500).json({
          success: false,
          message: "Error al obtener resumen de pedidos"
        });
      }

      res.json({
        success: true,
        data: {
          totales: {
            total_pedidos: totales[0].total_pedidos || 0,
            entregados: totales[0].entregados || 0,
            pendientes: totales[0].pendientes || 0,
            cancelados: totales[0].cancelados || 0,
            ingresos_totales: totales[0].ingresos_totales || 0,
            ticket_promedio: Math.round(totales[0].ticket_promedio || 0)
          },
          resumen_por_estado: resumen
        }
      });
    });
  });
});

// =============================================
// RESUMEN DE PRODUCTOS (Dashboard)
// =============================================
router.get("/resumen-productos", verificarToken, (req, res) => {
  if (req.usuarioRol !== 1) {
    return res.status(403).json({
      success: false,
      message: "Acceso denegado. Solo administradores."
    });
  }

  const sqlTopVendidos = `
    SELECT p.ID_Producto, p.Nombre_producto, p.Precio, p.imagen,
           SUM(dp.Cantidad) AS TotalVendido
    FROM detalle_pedido dp
    INNER JOIN producto p ON dp.ID_Producto = p.ID_Producto
    INNER JOIN pedido pe ON dp.ID_Pedido = pe.ID_Pedido
    WHERE pe.Estado = 'Entregado'
    GROUP BY p.ID_Producto
    ORDER BY TotalVendido DESC
    LIMIT 10
  `;

  const sqlStockBajo = `
    SELECT ID_Producto, Nombre_producto, Stock, Precio, imagen,
      CASE 
        WHEN Stock <= 0 THEN 'Crítico - Sin stock'
        WHEN Stock <= 5 THEN 'Muy bajo'
        ELSE 'Bajo'
      END AS nivel_stock
    FROM producto
    WHERE Stock <= 10
    ORDER BY Stock ASC
  `;

  Promise.all([
    new Promise((resolve, reject) => {
      db.query(sqlTopVendidos, (err, results) => {
        if (err) reject(err);
        else resolve(results);
      });
    }),
    new Promise((resolve, reject) => {
      db.query(sqlStockBajo, (err, results) => {
        if (err) reject(err);
        else resolve(results);
      });
    })
  ])
    .then(([productosMasVendidos, productosStockBajo]) => {
      res.json({
        success: true,
        data: {
          productos_mas_vendidos: productosMasVendidos,
          productos_stock_bajo: productosStockBajo,
          total_mas_vendidos: productosMasVendidos.length,
          total_stock_bajo: productosStockBajo.length
        }
      });
    })
    .catch(err => {
      console.error("Error al obtener estadísticas:", err);
      res.status(500).json({ success: false, message: "Error al obtener estadísticas" });
    });
});

// =============================================
// ALERTA DE STOCK
// =============================================
router.post("/alerta-stock", verificarToken, (req, res) => {
  const sql = `
    SELECT ID_Producto, Nombre_producto, Stock,
      CASE 
        WHEN Stock <= 0 THEN 'Crítico - Sin stock'
        WHEN Stock <= 5 THEN 'Muy bajo'
        ELSE 'Bajo'
      END AS nivel_stock
    FROM producto
    WHERE Stock <= 10 AND Estado = 1
    ORDER BY Stock ASC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error al obtener alertas de stock:", err);
      return res.status(500).json({
        success: false,
        message: "Error al obtener alertas de stock"
      });
    }

    const alertas = results.map(p =>
      `${p.Nombre_producto} - Stock: ${p.Stock} (${p.nivel_stock})`
    );

    res.json({
      success: true,
      alertas: alertas,
      productos: results
    });
  });
});
// =============================================
// TOP 10 PRODUCTOS MÁS VENDIDOS (para usuarios)
// =============================================
router.get("/top-productos", verificarToken, (req, res) => {
  const sql = `
    SELECT 
      p.ID_Producto,
      p.Nombre_producto,
      p.Precio,
      p.imagen,
      p.Stock,
      SUM(dp.Cantidad) AS TotalVendido
    FROM detalle_pedido dp
    INNER JOIN producto p ON dp.ID_Producto = p.ID_Producto
    INNER JOIN pedido pe ON dp.ID_Pedido = pe.ID_Pedido
    WHERE pe.Estado = 'Entregado' AND p.Estado = 1 AND p.Stock > 0
    GROUP BY p.ID_Producto
    ORDER BY TotalVendido DESC
    LIMIT 10
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error al obtener top productos:", err);
      return res.status(500).json({ success: false, message: "Error al obtener estadísticas" });
    }
    
    res.json({
      success: true,
      data: results
    });
  });
});
module.exports = router;