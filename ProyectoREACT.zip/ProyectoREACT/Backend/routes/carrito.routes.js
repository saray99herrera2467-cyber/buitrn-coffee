const express = require("express");
const router = express.Router();
const db = require("../config/db");
const jwt = require("jsonwebtoken");

const SECRET = "secreto123";

// ============================================
// MIDDLEWARE: Verificar Token
// ============================================
const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ 
      success: false,
      message: "Token requerido" 
    });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ 
        success: false,
        message: "Token inválido" 
      });
    }
    req.usuarioId = decoded.id;
    req.usuarioRol = decoded.rol;
    next();
  });
};

// =============================================
// 🛒 OBTENER CARRITO DEL USUARIO
// =============================================
/**
 * @swagger
 * /carrito:
 *   get:
 *     summary: Obtener carrito del usuario autenticado
 *     description: Retorna todos los productos en el carrito del usuario
 *     tags: [Carrito]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Carrito obtenido exitosamente
 *       401:
 *         description: No autenticado
 */
router.get("/", verificarToken, (req, res) => {
  const usuarioId = req.usuarioId;

  const sql = `
    SELECT 
      c.ID_Carrito, 
      c.Cantidad, 
      p.ID_Producto, 
      p.Nombre_producto, 
      p.Precio, 
      p.imagen, 
      p.Descripcion,
      p.Stock,
      (c.Cantidad * p.Precio) AS subtotal
    FROM carrito c
    INNER JOIN producto p ON c.ID_Producto = p.ID_Producto
    WHERE c.ID_Usuario = ?
    ORDER BY c.ID_Carrito DESC
  `;

  db.query(sql, [usuarioId], (err, results) => {
    if (err) {
      console.error("Error al obtener carrito:", err);
      return res.status(500).json({
        success: false,
        message: "Error al obtener carrito"
      });
    }
    
    // Calcular totales
    const total = results.reduce((sum, item) => sum + (item.Precio * item.Cantidad), 0);
    const totalItems = results.reduce((sum, item) => sum + item.Cantidad, 0);
    
    res.json({
      success: true,
      data: {
        items: results,
        total: total,
        totalItems: totalItems
      }
    });
  });
});

// =============================================
// ➕ AGREGAR PRODUCTO AL CARRITO
// =============================================
/**
 * @swagger
 * /carrito:
 *   post:
 *     summary: Agregar producto al carrito
 *     description: Agrega un producto al carrito del usuario. Si ya existe, aumenta la cantidad.
 *     tags: [Carrito]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - productoId
 *             properties:
 *               productoId:
 *                 type: integer
 *                 example: 1
 *               cantidad:
 *                 type: integer
 *                 example: 2
 *     responses:
 *       200:
 *         description: Producto agregado exitosamente
 *       400:
 *         description: Datos inválidos o producto sin stock
 *       401:
 *         description: No autenticado
 */
router.post("/", verificarToken, (req, res) => {
  const usuarioId = req.usuarioId;
  const { productoId, cantidad = 1 } = req.body;

  console.log("========== AGREGAR AL CARRITO ==========");
  console.log("usuarioId:", usuarioId);
  console.log("productoId:", productoId);
  console.log("cantidad:", cantidad);

  if (!productoId) {
    return res.status(400).json({
      success: false,
      message: "ID de producto requerido"
    });
  }

  // Verificar stock del producto
  const stockSql = "SELECT Stock, Nombre_producto FROM producto WHERE ID_Producto = ? AND Estado = 1";
  
  db.query(stockSql, [productoId], (err, productResults) => {
    if (err) {
      console.error("Error al verificar stock:", err);
      return res.status(500).json({
        success: false,
        message: "Error al verificar stock"
      });
    }

    if (productResults.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Producto no disponible"
      });
    }

    const product = productResults[0];
    if (product.Stock < cantidad) {
      return res.status(400).json({
        success: false,
        message: `Stock insuficiente. Disponible: ${product.Stock}`
      });
    }

    // Verificar si el producto ya está en el carrito
    const checkSql = "SELECT * FROM carrito WHERE ID_Usuario = ? AND ID_Producto = ?";
    
    db.query(checkSql, [usuarioId, productoId], (err, results) => {
      if (err) {
        console.error("Error al verificar carrito:", err);
        return res.status(500).json({
          success: false,
          message: "Error al verificar carrito"
        });
      }

      if (results.length > 0) {
        // Actualizar cantidad
        const nuevaCantidad = results[0].Cantidad + cantidad;
        
        // Verificar que no exceda el stock
        if (product.Stock < nuevaCantidad) {
          return res.status(400).json({
            success: false,
            message: `Stock insuficiente. Disponible: ${product.Stock}`
          });
        }

        const updateSql = "UPDATE carrito SET Cantidad = ? WHERE ID_Carrito = ?";
        
        db.query(updateSql, [nuevaCantidad, results[0].ID_Carrito], (err) => {
          if (err) {
            console.error("Error al actualizar:", err);
            return res.status(500).json({
              success: false,
              message: "Error al actualizar carrito"
            });
          }
          console.log("✅ Cantidad actualizada a:", nuevaCantidad);
          res.json({
            success: true,
            message: "Cantidad actualizada",
            data: { cantidad: nuevaCantidad }
          });
        });
      } else {
        // Insertar nuevo producto
        const insertSql = "INSERT INTO carrito (ID_Usuario, ID_Producto, Cantidad) VALUES (?, ?, ?)";
        
        db.query(insertSql, [usuarioId, productoId, cantidad], (err, result) => {
          if (err) {
            console.error("Error al insertar:", err);
            return res.status(500).json({
              success: false,
              message: "Error al agregar al carrito"
            });
          }
          console.log("✅ Producto insertado, ID:", result.insertId);
          res.json({
            success: true,
            message: "Producto agregado al carrito",
            data: { idCarrito: result.insertId }
          });
        });
      }
    });
  });
});

// =============================================
// ✏️ ACTUALIZAR CANTIDAD
// =============================================
/**
 * @swagger
 * /carrito/{itemId}:
 *   put:
 *     summary: Actualizar cantidad de un producto en el carrito
 *     description: Cambia la cantidad de un producto específico en el carrito
 *     tags: [Carrito]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: itemId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del carrito
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - cantidad
 *             properties:
 *               cantidad:
 *                 type: integer
 *                 example: 3
 *     responses:
 *       200:
 *         description: Cantidad actualizada exitosamente
 *       400:
 *         description: Cantidad inválida o sin stock
 *       401:
 *         description: No autenticado
 *       404:
 *         description: Producto no encontrado en el carrito
 */
router.put("/:itemId", verificarToken, (req, res) => {
  const itemId = req.params.itemId;
  const { cantidad } = req.body;
  const usuarioId = req.usuarioId;

  if (!cantidad || cantidad < 1) {
    return res.status(400).json({
      success: false,
      message: "La cantidad debe ser al menos 1"
    });
  }

  // Verificar que el producto existe en el carrito y obtener su stock
  const checkSql = `
    SELECT c.ID_Carrito, c.ID_Producto, p.Stock 
    FROM carrito c
    INNER JOIN producto p ON c.ID_Producto = p.ID_Producto
    WHERE c.ID_Carrito = ? AND c.ID_Usuario = ?
  `;
  
  db.query(checkSql, [itemId, usuarioId], (err, results) => {
    if (err) {
      console.error("Error al verificar carrito:", err);
      return res.status(500).json({
        success: false,
        message: "Error al verificar carrito"
      });
    }

    if (results.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Producto no encontrado en el carrito"
      });
    }

    if (results[0].Stock < cantidad) {
      return res.status(400).json({
        success: false,
        message: `Stock insuficiente. Disponible: ${results[0].Stock}`
      });
    }

    const sql = "UPDATE carrito SET Cantidad = ? WHERE ID_Carrito = ? AND ID_Usuario = ?";
    
    db.query(sql, [cantidad, itemId, usuarioId], (err) => {
      if (err) {
        console.error("Error al actualizar:", err);
        return res.status(500).json({
          success: false,
          message: "Error al actualizar carrito"
        });
      }
      res.json({
        success: true,
        message: "Cantidad actualizada",
        data: { cantidad: cantidad }
      });
    });
  });
});

// =============================================
// ❌ ELIMINAR PRODUCTO DEL CARRITO
// =============================================
/**
 * @swagger
 * /carrito/{itemId}:
 *   delete:
 *     summary: Eliminar producto del carrito
 *     description: Elimina un producto específico del carrito
 *     tags: [Carrito]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: itemId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del carrito
 *     responses:
 *       200:
 *         description: Producto eliminado exitosamente
 *       401:
 *         description: No autenticado
 *       404:
 *         description: Producto no encontrado en el carrito
 */
router.delete("/:itemId", verificarToken, (req, res) => {
  const itemId = req.params.itemId;
  const usuarioId = req.usuarioId;

  // Verificar que el producto existe en el carrito
  const checkSql = "SELECT ID_Carrito FROM carrito WHERE ID_Carrito = ? AND ID_Usuario = ?";
  
  db.query(checkSql, [itemId, usuarioId], (err, results) => {
    if (err) {
      console.error("Error al verificar carrito:", err);
      return res.status(500).json({
        success: false,
        message: "Error al verificar carrito"
      });
    }

    if (results.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Producto no encontrado en el carrito"
      });
    }

    const sql = "DELETE FROM carrito WHERE ID_Carrito = ? AND ID_Usuario = ?";
    
    db.query(sql, [itemId, usuarioId], (err) => {
      if (err) {
        console.error("Error al eliminar:", err);
        return res.status(500).json({
          success: false,
          message: "Error al eliminar del carrito"
        });
      }
      res.json({
        success: true,
        message: "Producto eliminado del carrito"
      });
    });
  });
});

// =============================================
// 🗑️ VACIAR CARRITO
// =============================================
/**
 * @swagger
 * /carrito/vaciar:
 *   delete:
 *     summary: Vaciar carrito completo
 *     description: Elimina todos los productos del carrito del usuario
 *     tags: [Carrito]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Carrito vaciado exitosamente
 *       401:
 *         description: No autenticado
 */
router.delete("/vaciar", verificarToken, (req, res) => {
  const usuarioId = req.usuarioId;

  // Verificar si el carrito tiene productos
  const checkSql = "SELECT COUNT(*) as total FROM carrito WHERE ID_Usuario = ?";
  
  db.query(checkSql, [usuarioId], (err, results) => {
    if (err) {
      console.error("Error al verificar carrito:", err);
      return res.status(500).json({
        success: false,
        message: "Error al verificar carrito"
      });
    }

    if (results[0].total === 0) {
      return res.status(400).json({
        success: false,
        message: "El carrito ya está vacío"
      });
    }

    const sql = "DELETE FROM carrito WHERE ID_Usuario = ?";
    
    db.query(sql, [usuarioId], (err) => {
      if (err) {
        console.error("Error al vaciar carrito:", err);
        return res.status(500).json({
          success: false,
          message: "Error al vaciar carrito"
        });
      }
      res.json({
        success: true,
        message: "Carrito vaciado exitosamente"
      });
    });
  });
});

module.exports = router;