const express = require("express");
const router = express.Router();
const db = require("../config/db");
const jwt = require("jsonwebtoken");
const { enviarConfirmacionPQRS, enviarRespuestaPQRS } = require('../utils/emailService');

const SECRET = "secreto123";

// Middleware verificarToken
const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Token requerido" });
  
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: "Token inválido" });
    req.usuarioId = decoded.id;
    req.usuarioRol = decoded.rol;
    next();
  });
};

/**
 * @swagger
 * tags:
 *   name: PQRS
 *   description: Peticiones, Quejas, Reclamos y Sugerencias
 */

/**
 * @swagger
 * /pqrs:
 *   post:
 *     summary: Crear una PQRS
 *     description: Crea una nueva PQRS. Puede ser anónimo o con usuario autenticado.
 *     tags: [PQRS]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/PQRSCreacion'
 *     responses:
 *       201:
 *         description: PQRS creada correctamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: PQRS creada correctamente
 *                 codigo_referencia:
 *                   type: string
 *       400:
 *         description: Faltan campos obligatorios
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Error al crear PQRS
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.post("/", async (req, res) => {
  const { nombre, email, telefono, tipo, descripcion, codigo_referencia, id_usuario } = req.body;

  if (!nombre || !email || !tipo || !descripcion || !codigo_referencia) {
    return res.status(400).json({ message: "Faltan campos obligatorios" });
  }

  const sql = `
    INSERT INTO pqrs (Codigo_Referencia, ID_Usuario, Nombre, Email, Telefono, Tipo, Descripcion, Estado)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'pendiente')
  `;

  db.query(sql, [codigo_referencia, id_usuario || null, nombre, email, telefono || null, tipo, descripcion], async (err, result) => {
    if (err) {
      console.error("Error al crear PQRS:", err);
      return res.status(500).json({ message: "Error al crear PQRS" });
    }
    
    try {
      await enviarConfirmacionPQRS(email, nombre, codigo_referencia, tipo);
      console.log(`📧 Confirmación PQRS enviada a ${email}`);
    } catch (error) {
      console.error("Error al enviar confirmación PQRS:", error);
    }
    
    res.status(201).json({ 
      message: "PQRS creada correctamente",
      id: result.insertId,
      codigo_referencia
    });
  });
});

/**
 * @swagger
 * /pqrs/consultar/{codigo}:
 *   get:
 *     summary: Consultar PQRS por código
 *     description: Obtiene los detalles de una PQRS específica usando su código de referencia.
 *     tags: [PQRS]
 *     parameters:
 *       - in: path
 *         name: codigo
 *         required: true
 *         schema:
 *           type: string
 *         description: Código de referencia de la PQRS
 *     responses:
 *       200:
 *         description: Detalles de la PQRS
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PQRS'
 *       404:
 *         description: PQRS no encontrada
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/consultar/:codigo", (req, res) => {
  const codigo = req.params.codigo;

  const sql = `
    SELECT Codigo_Referencia, Tipo, Descripcion, Estado, Fecha_Creacion, Respuesta
    FROM pqrs 
    WHERE Codigo_Referencia = ?
  `;

  db.query(sql, [codigo], (err, results) => {
    if (err) return res.status(500).json(err);
    if (results.length === 0) {
      return res.status(404).json({ message: "No se encontró ninguna PQRS con ese código" });
    }
    res.json(results[0]);
  });
});

/**
 * @swagger
 * /pqrs/mis-pqrs:
 *   get:
 *     summary: Obtener mis PQRS (Usuario autenticado)
 *     description: Devuelve la lista de PQRS del usuario autenticado.
 *     tags: [PQRS]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de PQRS del usuario
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/PQRS'
 *       401:
 *         description: Token inválido
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/mis-pqrs", verificarToken, (req, res) => {
  const usuarioId = req.usuarioId;

  const sql = `
    SELECT ID_PQRS, Codigo_Referencia, Tipo, Descripcion, Estado, 
           Fecha_Creacion, Respuesta
    FROM pqrs 
    WHERE ID_Usuario = ?
    ORDER BY Fecha_Creacion DESC
  `;

  db.query(sql, [usuarioId], (err, results) => {
    if (err) {
      console.error("Error al obtener PQRS del usuario:", err);
      return res.status(500).json({ message: "Error al obtener tus PQRS" });
    }
    res.json(results);
  });
});

/**
 * @swagger
 * /pqrs/admin:
 *   get:
 *     summary: Obtener todas las PQRS (Admin)
 *     description: Devuelve la lista completa de PQRS del sistema. Solo administradores.
 *     tags: [PQRS]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de PQRS
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/PQRS'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/admin", verificarToken, (req, res) => {
  if (req.usuarioRol !== 1) {
    return res.status(403).json({ message: "No tienes permisos para ver PQRS" });
  }

  const sql = `
    SELECT p.*, u.Nombre_usuario as UsuarioNombre, u.Correo as UsuarioCorreo
    FROM pqrs p
    LEFT JOIN usuario u ON p.ID_Usuario = u.ID_Usuario
    ORDER BY p.Fecha_Creacion DESC
  `;

  db.query(sql, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

/**
 * @swagger
 * /pqrs/admin/{id}:
 *   patch:
 *     summary: Actualizar estado de PQRS (Admin)
 *     description: Cambia el estado y/o añade respuesta a una PQRS. Solo administradores.
 *     tags: [PQRS]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID de la PQRS
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               estado:
 *                 type: string
 *                 enum: [pendiente, en_proceso, resuelta, cerrada]
 *               respuesta:
 *                 type: string
 *     responses:
 *       200:
 *         description: PQRS actualizada correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: PQRS no encontrada
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.patch("/admin/:id", verificarToken, async (req, res) => {
  if (req.usuarioRol !== 1) {
    return res.status(403).json({ message: "No tienes permisos" });
  }

  const { id } = req.params;
  const { estado, respuesta } = req.body;

  const getUserSql = `
    SELECT p.Email, p.Nombre, p.Codigo_Referencia
    FROM pqrs p
    WHERE p.ID_PQRS = ?
  `;

  db.query(getUserSql, [id], async (err, userResult) => {
    if (err) return res.status(500).json(err);
    
    const sql = "UPDATE pqrs SET Estado = ?, Respuesta = ? WHERE ID_PQRS = ?";
    db.query(sql, [estado, respuesta || null, id], async (err, result) => {
      if (err) return res.status(500).json(err);
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "PQRS no encontrada" });
      }
      
      if (respuesta && userResult.length > 0) {
        try {
          await enviarRespuestaPQRS(
            userResult[0].Email, 
            userResult[0].Nombre, 
            respuesta, 
            userResult[0].Codigo_Referencia
          );
          console.log(`📧 Respuesta PQRS enviada a ${userResult[0].Email}`);
        } catch (error) {
          console.error("Error al enviar respuesta PQRS:", error);
        }
      }
      
      res.json({ message: "PQRS actualizada correctamente" });
    });
  });
});

module.exports = router;