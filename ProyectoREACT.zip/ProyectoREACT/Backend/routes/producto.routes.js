const express = require("express");
const router = express.Router();
const db = require("../config/db");
const jwt = require("jsonwebtoken");

const SECRET = "secreto123";

// Middleware verificarToken
const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }
    req.usuarioId = decoded.id;
    req.usuarioRol = decoded.rol;
    next();
  });
};

// Middleware verificarAdmin
const verificarAdmin = (req, res, next) => {
  if (req.usuarioRol !== 1) {
    return res.status(403).json({ message: "No tienes permisos de administrador" });
  }
  next();
};

// =============================================
// ⚠️ ALERTA DE STOCK (para el frontend)
// =============================================
router.post("/alerta-stock", verificarToken, (req, res) => {
  const sql = `
    SELECT ID_Producto, Nombre_producto, Stock, Precio,
      CASE 
        WHEN Stock <= 0 THEN 'Crítico - Sin stock'
        WHEN Stock <= 5 THEN 'Muy bajo'
        ELSE 'Bajo'
      END AS nivel_stock
    FROM producto
    WHERE Stock <= 10 AND Estado = 1
    ORDER BY Stock ASC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error al obtener alertas de stock:", err);
      return res.status(500).json({ 
        success: false, 
        message: "Error al obtener alertas de stock" 
      });
    }

    // Formatear alertas para el frontend
    const alertas = results.map(p => 
      `${p.Nombre_producto} - Stock: ${p.Stock} (${p.nivel_stock})`
    );

    res.json({
      success: true,
      alertas: alertas,
      productos: results
    });
  });
});

/**
 * @swagger
 * tags:
 *   name: Productos
 *   description: Gestión y consulta de productos
 */

/**
 * @swagger
 * /productos/activos:
 *   get:
 *     summary: Obtener productos activos
 *     description: Devuelve la lista de productos activos con stock disponible. No requiere autenticación.
 *     tags: [Productos]
 *     responses:
 *       200:
 *         description: Lista de productos activos
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Producto'
 */
router.get("/activos", (req, res) => {
  const sql = `
    SELECT p.*, 
           u.Nombre_usuario as Nombre_Proveedor,
           p.calificacion_promedio,
           p.total_resenas
    FROM producto p
    LEFT JOIN usuario u ON p.ID_Proveedor = u.ID_Usuario
    WHERE p.Estado = 1 AND p.Stock > 0
    ORDER BY p.ID_Producto DESC
  `;
  
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

/**
 * @swagger
 * /productos:
 *   get:
 *     summary: Obtener todos los productos (Admin)
 *     description: Devuelve la lista completa de productos incluyendo inhabilitados. Requiere autenticación de administrador.
 *     tags: [Productos]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de productos
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Producto'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/", verificarToken, verificarAdmin, (req, res) => {
  const sql = `
    SELECT p.*, 
           u.Nombre_usuario as Nombre_Proveedor, 
           u.Apellido as Apellido_Proveedor,
           p.calificacion_promedio,
           p.total_resenas
    FROM producto p
    LEFT JOIN usuario u ON p.ID_Proveedor = u.ID_Usuario
    ORDER BY p.ID_Producto DESC
  `;
  
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

/**
 * @swagger
 * /productos/{id}:
 *   get:
 *     summary: Obtener producto por ID
 *     description: Devuelve los detalles de un producto específico.
 *     tags: [Productos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del producto
 *     responses:
 *       200:
 *         description: Detalles del producto
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Producto'
 *       404:
 *         description: Producto no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/:id", (req, res) => {
  const id = req.params.id;
  
  db.query(
    "SELECT * FROM producto WHERE ID_Producto = ?",
    [id],
    (err, results) => {
      if (err) return res.status(500).json(err);
      if (results.length === 0) {
        return res.status(404).json({ message: "Producto no encontrado" });
      }
      res.json(results[0]);
    }
  );
});

/**
 * @swagger
 * /productos:
 *   post:
 *     summary: Crear producto (Admin)
 *     description: Crea un nuevo producto. Solo administradores.
 *     tags: [Productos]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ProductoCreacion'
 *     responses:
 *       201:
 *         description: Producto creado correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       400:
 *         description: Datos inválidos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.post("/", verificarToken, verificarAdmin, (req, res) => {
  const { Nombre_producto, Descripcion, Categoria, Precio, Stock, imagen, ID_Proveedor } = req.body;
  
  if (!Nombre_producto || !Categoria || !Precio || Stock === undefined) {
    return res.status(400).json({ 
      message: "Faltan campos obligatorios: Nombre_producto, Categoria, Precio, Stock" 
    });
  }
  
  const sql = `
    INSERT INTO producto (Nombre_producto, Descripcion, Categoria, Precio, Stock, imagen, Estado, ID_Proveedor)
    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
  `;
  
  db.query(
    sql,
    [Nombre_producto, Descripcion || null, Categoria, Precio, Stock, imagen || null, ID_Proveedor || null],
    (err, result) => {
      if (err) {
        console.error("Error al crear producto:", err);
        return res.status(500).json({ message: "Error al crear producto" });
      }
      
      res.status(201).json({ 
        message: "Producto creado correctamente",
        id: result.insertId 
      });
    }
  );
});

/**
 * @swagger
 * /productos/{id}:
 *   put:
 *     summary: Actualizar producto (Admin)
 *     description: Actualiza la información de un producto existente. Solo administradores.
 *     tags: [Productos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del producto
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ProductoCreacion'
 *     responses:
 *       200:
 *         description: Producto actualizado correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       404:
 *         description: Producto no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.put("/:id", verificarToken, verificarAdmin, (req, res) => {
  const id = req.params.id;
  const { Nombre_producto, Descripcion, Categoria, Precio, Stock, imagen, ID_Proveedor } = req.body;
  
  const sql = `
    UPDATE producto 
    SET Nombre_producto = ?, Descripcion = ?, Categoria = ?, Precio = ?, Stock = ?, imagen = ?, ID_Proveedor = ?
    WHERE ID_Producto = ?
  `;
  
  db.query(
    sql,
    [Nombre_producto, Descripcion, Categoria, Precio, Stock, imagen, ID_Proveedor || null, id],
    (err, result) => {
      if (err) {
        console.error("Error al actualizar producto:", err);
        return res.status(500).json({ message: "Error al actualizar producto" });
      }
      
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Producto no encontrado" });
      }
      
      res.json({ message: "Producto actualizado correctamente" });
    }
  );
});

/**
 * @swagger
 * /productos/{id}/inhabilitar:
 *   patch:
 *     summary: Inhabilitar producto (Admin)
 *     description: Cambia el estado del producto a inhabilitado. Solo administradores.
 *     tags: [Productos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del producto
 *     responses:
 *       200:
 *         description: Producto inhabilitado correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       404:
 *         description: Producto no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.patch("/:id/inhabilitar", verificarToken, verificarAdmin, (req, res) => {
  const id = req.params.id;
  const sql = "UPDATE producto SET Estado = 0 WHERE ID_Producto = ?";
  
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error al inhabilitar producto:", err);
      return res.status(500).json({ message: "Error al inhabilitar producto" });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Producto no encontrado" });
    }
    res.json({ message: "Producto inhabilitado correctamente" });
  });
});

/**
 * @swagger
 * /productos/{id}/habilitar:
 *   patch:
 *     summary: Habilitar producto (Admin)
 *     description: Cambia el estado del producto a activo. Solo administradores.
 *     tags: [Productos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del producto
 *     responses:
 *       200:
 *         description: Producto habilitado correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       404:
 *         description: Producto no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 * /productos:
 *   post:
 *     summary: Crear producto
 *     description: Crea un nuevo producto. **Requiere rol de administrador.**
 *     tags: [Productos]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Producto creado correctamente
 *       403:
 *         description: No tienes permisos de administrador
 */
router.patch("/:id/habilitar", verificarToken, verificarAdmin, (req, res) => {
  const id = req.params.id;
  const sql = "UPDATE producto SET Estado = 1 WHERE ID_Producto = ?";
  
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error al habilitar producto:", err);
      return res.status(500).json({ message: "Error al habilitar producto" });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Producto no encontrado" });
    }
    res.json({ message: "Producto habilitado correctamente" });
  });
});

module.exports = router;