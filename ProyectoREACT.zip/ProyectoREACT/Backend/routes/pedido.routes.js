const express = require("express");
const router = express.Router();
const db = require("../config/db");
const jwt = require("jsonwebtoken");
const { enviarConfirmacionPedido } = require('../utils/emailService');

const SECRET = "secreto123";

// Middleware verificarToken
const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Token requerido" });
  }
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Token inválido" });
    }
    req.usuarioId = decoded.id;
    next();
  });
};

/**
 * @swagger
 * tags:
 *   name: Pedidos
 *   description: Gestión de pedidos
 */

/**
 * @swagger
 * /pedidos:
 *   post:
 *     summary: Crear pedido
 *     description: Crea un nuevo pedido con los productos del carrito.
 *     tags: [Pedidos]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/PedidoCreacion'
 *     responses:
 *       201:
 *         description: Pedido creado correctamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Pedido creado correctamente
 *                 ID_Pedido:
 *                   type: integer
 *                 fecha_limite:
 *                   type: string
 *                   format: date-time
 *       400:
 *         description: El carrito está vacío
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       500:
 *         description: Error al crear el pedido
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.post("/", verificarToken, async (req, res) => {
  const usuarioId = req.usuarioId;
  const { items, subtotal, total } = req.body;

  console.log("📦 Creando pedido para usuario:", usuarioId);

  if (!items || items.length === 0) {
    return res.status(400).json({ message: "El pedido no tiene productos" });
  }

  const getUserSql = "SELECT Nombre_usuario, Correo FROM usuario WHERE ID_Usuario = ?";
  const usuario = await new Promise((resolve, reject) => {
    db.query(getUserSql, [usuarioId], (err, result) => {
      if (err) reject(err);
      else resolve(result[0]);
    });
  });

  const fecha = new Date();
  const fechaLimite = new Date();
  fechaLimite.setDate(fechaLimite.getDate() + 2);
  const fechaLimiteFormateada = fechaLimite.toLocaleDateString('es-CO');

  const sqlPedido = `
    INSERT INTO pedido (ID_Usuario, Fecha, Subtotal, Total, Estado, Fecha_Limite, Pagado)
    VALUES (?, ?, ?, ?, 'Pendiente', ?, 0)
  `;

  db.query(sqlPedido, [usuarioId, fecha, subtotal, total, fechaLimite], async (err, result) => {
    if (err) {
      console.error("Error al crear pedido:", err);
      return res.status(500).json({ message: "Error al crear pedido", error: err.message });
    }

    const pedidoId = result.insertId;

    const detalles = items.map(item => [
      pedidoId,
      item.ID_Producto,
      item.Cantidad,
      item.PrecioUnitario || item.Precio
    ]);

    const sqlDetalle = `
      INSERT INTO detalle_pedido (ID_Pedido, ID_Producto, Cantidad, PrecioUnitario)
      VALUES ?
    `;

    db.query(sqlDetalle, [detalles], (err) => {
      if (err) {
        console.error("Error al crear detalles:", err);
        return res.status(500).json({ message: "Error al crear detalles del pedido" });
      }

      const updateStock = items.map(item => {
        return new Promise((resolve, reject) => {
          const sqlStock = "UPDATE producto SET Stock = Stock - ? WHERE ID_Producto = ?";
          db.query(sqlStock, [item.Cantidad, item.ID_Producto], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });
      });

      Promise.all(updateStock)
        .then(async () => {
          try {
            if (usuario && usuario.Correo) {
              await enviarConfirmacionPedido(
                usuario.Correo,
                usuario.Nombre_usuario,
                pedidoId,
                total,
                fechaLimiteFormateada
              );
              console.log(`📧 Confirmación de pedido enviada a ${usuario.Correo}`);
            }
          } catch (error) {
            console.error("Error al enviar confirmación de pedido:", error);
          }
          
          res.status(201).json({
            message: "Pedido creado correctamente",
            ID_Pedido: pedidoId,
            fecha: fecha,
            fecha_limite: fechaLimite
          });
        })
        .catch(err => {
          console.error("Error al actualizar stock:", err);
          res.status(500).json({ message: "Error al actualizar stock" });
        });
    });
  });
});

/**
 * @swagger
 * /pedidos/historial:
 *   get:
 *     summary: Historial de pedidos del usuario
 *     description: Devuelve la lista de pedidos realizados por el usuario autenticado.
 *     tags: [Pedidos]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Historial de pedidos
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Pedido'
 *       401:
 *         description: Token inválido
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/historial", verificarToken, (req, res) => {
  const usuarioId = req.usuarioId;

  const sql = `
    SELECT 
      p.ID_Pedido,
      p.Fecha,
      p.Fecha_Limite,
      p.Subtotal,
      p.Total,
      p.Estado,
      p.Pagado,
      COUNT(dp.ID_Detalle) as CantidadProductos,
      GROUP_CONCAT(DISTINCT pr.Nombre_producto SEPARATOR '||') as Productos
    FROM pedido p
    INNER JOIN detalle_pedido dp ON p.ID_Pedido = dp.ID_Pedido
    INNER JOIN producto pr ON dp.ID_Producto = pr.ID_Producto
    WHERE p.ID_Usuario = ?
    GROUP BY p.ID_Pedido
    ORDER BY p.Fecha DESC
  `;

  db.query(sql, [usuarioId], (err, results) => {
    if (err) {
      console.error("Error en historial:", err);
      return res.status(500).json({ message: "Error al obtener historial", error: err.message });
    }

    const pedidos = results.map(pedido => ({
      ...pedido,
      ProductosLista: pedido.Productos ? pedido.Productos.split('||') : []
    }));

    res.json(pedidos);
  });
});

/**
 * @swagger
 * /pedidos/detalle/{pedidoId}:
 *   get:
 *     summary: Detalle de un pedido específico
 *     description: Devuelve los detalles completos de un pedido (productos, cantidades, precios).
 *     tags: [Pedidos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: pedidoId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del pedido
 *     responses:
 *       200:
 *         description: Detalle del pedido
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 ID_Pedido:
 *                   type: integer
 *                 items:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       ID_Producto:
 *                         type: integer
 *                       Nombre_producto:
 *                         type: string
 *                       Cantidad:
 *                         type: integer
 *                       PrecioUnitario:
 *                         type: number
 *       404:
 *         description: Pedido no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/detalle/:pedidoId", verificarToken, (req, res) => {
  const usuarioId = req.usuarioId;
  const pedidoId = req.params.pedidoId;

  const sqlPedido = `
    SELECT ID_Pedido, Fecha, Subtotal, Total, Estado, Fecha_Limite, Pagado
    FROM pedido
    WHERE ID_Pedido = ? AND ID_Usuario = ?
  `;

  db.query(sqlPedido, [pedidoId, usuarioId], (err, pedidoResult) => {
    if (err) {
      console.error("Error al obtener pedido:", err);
      return res.status(500).json({ message: "Error al obtener pedido" });
    }

    if (pedidoResult.length === 0) {
      return res.status(404).json({ message: "Pedido no encontrado" });
    }

    const pedido = pedidoResult[0];

    const sqlProductos = `
      SELECT 
        dp.ID_Producto,
        dp.Cantidad,
        dp.PrecioUnitario,
        pr.Nombre_producto,
        pr.imagen,
        pr.Descripcion
      FROM detalle_pedido dp
      INNER JOIN producto pr ON dp.ID_Producto = pr.ID_Producto
      WHERE dp.ID_Pedido = ?
    `;

    db.query(sqlProductos, [pedidoId], (err, productosResult) => {
      if (err) {
        console.error("Error al obtener productos:", err);
        return res.status(500).json({ message: "Error al obtener productos del pedido" });
      }

      const items = productosResult.map(item => ({
        ID_Producto: item.ID_Producto,
        Nombre_producto: item.Nombre_producto,
        Cantidad: item.Cantidad,
        PrecioUnitario: item.PrecioUnitario,
        imagen: item.imagen,
        Descripcion: item.Descripcion
      }));

      res.json({
        ID_Pedido: pedido.ID_Pedido,
        Fecha: pedido.Fecha,
        Subtotal: pedido.Subtotal,
        Total: pedido.Total,
        Estado: pedido.Estado,
        Fecha_Limite: pedido.Fecha_Limite,
        Pagado: pedido.Pagado,
        items: items
      });
    });
  });
});

/**
 * @swagger
 * /pedidos/admin/todos:
 *   get:
 *     summary: Obtener todos los pedidos (Admin)
 *     description: Devuelve la lista completa de pedidos del sistema. Solo administradores.
 *     tags: [Pedidos]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de pedidos
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Pedido'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.get("/admin/todos", verificarToken, (req, res) => {
  const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
  
  db.query(checkAdminSql, [req.usuarioId], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0 || result[0].ID_Rol !== 1) {
      return res.status(403).json({ message: "No tienes permisos" });
    }

    const sql = `
      SELECT 
        p.ID_Pedido,
        p.Fecha,
        p.Fecha_Limite,
        p.Subtotal,
        p.Total,
        p.Estado,
        p.Pagado,
        u.Nombre_usuario,
        u.Apellido,
        u.Correo,
        u.Telefono,
        (SELECT COUNT(*) FROM detalle_pedido WHERE ID_Pedido = p.ID_Pedido) as CantidadProductos
      FROM pedido p
      JOIN usuario u ON p.ID_Usuario = u.ID_Usuario
      ORDER BY p.Fecha DESC
    `;

    db.query(sql, (err, results) => {
      if (err) return res.status(500).json(err);
      res.json(results);
    });
  });
});

/**
 * @swagger
 * /pedidos/admin/estado/{pedidoId}:
 *   patch:
 *     summary: Actualizar estado de pedido (Admin)
 *     description: Cambia el estado de un pedido. Solo administradores.
 *     tags: [Pedidos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: pedidoId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del pedido
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - estado
 *             properties:
 *               estado:
 *                 type: string
 *                 enum: [Pendiente, Enviado, Entregado, Cancelado]
 *                 example: Entregado
 *     responses:
 *       200:
 *         description: Estado actualizado correctamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       400:
 *         description: Estado no válido
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       403:
 *         description: No tienes permisos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *       404:
 *         description: Pedido no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 */
router.patch("/admin/estado/:pedidoId", verificarToken, (req, res) => {
  const { pedidoId } = req.params;
  const { estado } = req.body;

  const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
  
  db.query(checkAdminSql, [req.usuarioId], (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0 || result[0].ID_Rol !== 1) {
      return res.status(403).json({ message: "No tienes permisos" });
    }

    const estadosValidos = ['Pendiente', 'Enviado', 'Entregado', 'Cancelado'];
    if (!estadosValidos.includes(estado)) {
      return res.status(400).json({ message: "Estado no válido" });
    }

    const sql = "UPDATE pedido SET Estado = ? WHERE ID_Pedido = ?";
    db.query(sql, [estado, pedidoId], (err, result) => {
      if (err) return res.status(500).json(err);
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Pedido no encontrado" });
      }
      res.json({ message: "Estado actualizado correctamente" });
    });
  });
});
/**
 * @swagger
 * /pedidos/admin/detalle/{pedidoId}:
 *   get:
 *     summary: Obtener detalle de pedido (Admin)
 *     description: Devuelve los detalles completos de un pedido para el administrador.
 *     tags: [Pedidos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: pedidoId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del pedido
 *     responses:
 *       200:
 *         description: Detalle del pedido
 *       404:
 *         description: Pedido no encontrado
 *       403:
 *         description: No tienes permisos
 */
router.get("/admin/detalle/:pedidoId", verificarToken, (req, res) => {
  const { pedidoId } = req.params;

  // 🔥 Verificar que el usuario es administrador
  const checkAdminSql = "SELECT ID_Rol FROM usuario WHERE ID_Usuario = ?";
  
  db.query(checkAdminSql, [req.usuarioId], (err, result) => {
    if (err) {
      console.error("❌ Error al verificar admin:", err);
      return res.status(500).json({ 
        success: false, 
        message: "Error al verificar permisos" 
      });
    }
    
    if (result.length === 0 || result[0].ID_Rol !== 1) {
      return res.status(403).json({ 
        success: false, 
        message: "No tienes permisos de administrador" 
      });
    }

    // 🔥 Verificar que el pedido existe
    const checkPedidoSql = "SELECT ID_Pedido, Estado FROM pedido WHERE ID_Pedido = ?";
    
    db.query(checkPedidoSql, [pedidoId], (err, pedidoResult) => {
      if (err) {
        console.error("❌ Error al verificar pedido:", err);
        return res.status(500).json({ 
          success: false, 
          message: "Error al verificar pedido" 
        });
      }

      if (pedidoResult.length === 0) {
        return res.status(404).json({ 
          success: false, 
          message: `El pedido #${pedidoId} no existe` 
        });
      }

      // 🔥 Obtener los detalles del pedido
      const sql = `
        SELECT 
          dp.ID_Detalle,
          dp.ID_Producto,
          dp.Cantidad,
          dp.PrecioUnitario,
          p.Nombre_producto,
          p.Descripcion,
          p.imagen
        FROM detalle_pedido dp
        INNER JOIN producto p ON dp.ID_Producto = p.ID_Producto
        WHERE dp.ID_Pedido = ?
      `;

      db.query(sql, [pedidoId], (err, results) => {
        if (err) {
          console.error("❌ Error al obtener detalle:", err);
          return res.status(500).json({ 
            success: false, 
            message: "Error al obtener detalle del pedido" 
          });
        }

        if (results.length === 0) {
          return res.status(404).json({ 
            success: false, 
            message: `No hay productos en el pedido #${pedidoId}` 
          });
        }

        console.log(` Detalle del pedido #${pedidoId} encontrado:`, results.length, "productos");
        res.json(results);
      });
    });
  });
});


module.exports = router;