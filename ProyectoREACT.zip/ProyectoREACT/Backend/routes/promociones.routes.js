const express = require("express");
const router = express.Router();
const db = require("../config/db");
const jwt = require("jsonwebtoken");

const SECRET = "secreto123";

const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ success: false, message: "Token requerido" });
  }
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ success: false, message: "Token inválido" });
    }
    req.usuarioId = decoded.id;
    req.usuarioRol = decoded.rol;
    next();
  });
};

const verificarAdmin = (req, res, next) => {
  if (req.usuarioRol !== 1) {
    return res.status(403).json({
      success: false,
      message: "Acceso denegado. Solo administradores."
    });
  }
  next();
};

// =============================================
//  OBTENER PROMOCIONES ACTIVAS (Público)
// =============================================
router.get("/activas", (req, res) => {
  const sql = `
    SELECT 
      p.ID_Promocion,
      p.Nombre,
      p.Descripcion,
      p.Tipo,
      p.Valor,
      p.Codigo,
      p.ID_Producto,
      pr.Nombre_producto as Producto_Nombre,
      p.Minimo_Compra,
      p.Fecha_Inicio,
      p.Fecha_Fin,
      p.Stock_Limite,
      p.Usos_Actuales,
      CASE 
        WHEN p.Stock_Limite IS NOT NULL AND p.Usos_Actuales >= p.Stock_Limite THEN 0
        WHEN p.Fecha_Fin < NOW() THEN 0
        WHEN p.Estado = 0 THEN 0
        ELSE 1
      END as Disponible
    FROM promociones p
    LEFT JOIN producto pr ON p.ID_Producto = pr.ID_Producto
    WHERE p.Estado = 1 
      AND p.Fecha_Inicio <= NOW() 
      AND p.Fecha_Fin >= NOW()
      AND (p.Stock_Limite IS NULL OR p.Usos_Actuales < p.Stock_Limite)
    ORDER BY p.Fecha_Fin ASC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error al obtener promociones:", err);
      return res.status(500).json({ success: false, message: "Error al obtener promociones" });
    }
    res.json({ success: true, data: results });
  });
});

// =============================================
//  OBTENER TODAS LAS PROMOCIONES (Admin)
// =============================================
router.get("/admin/todas", verificarToken, verificarAdmin, (req, res) => {
  const sql = `
    SELECT 
      p.ID_Promocion,
      p.Nombre,
      p.Descripcion,
      p.Tipo,
      p.Valor,
      p.Codigo,
      p.ID_Producto,
      pr.Nombre_producto as Producto_Nombre,
      p.Minimo_Compra,
      p.Fecha_Inicio,
      p.Fecha_Fin,
      p.Stock_Limite,
      p.Usos_Actuales,
      p.Estado,
      p.Fecha_Creacion,
      CASE 
        WHEN p.Stock_Limite IS NOT NULL AND p.Usos_Actuales >= p.Stock_Limite THEN 'Agotado'
        WHEN p.Fecha_Fin < NOW() THEN 'Expirada'
        WHEN p.Estado = 0 THEN 'Inactiva'
        ELSE 'Activa'
      END as Estado_Texto
    FROM promociones p
    LEFT JOIN producto pr ON p.ID_Producto = pr.ID_Producto
    ORDER BY p.Fecha_Creacion DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error al obtener promociones:", err);
      return res.status(500).json({ success: false, message: "Error al obtener promociones" });
    }
    res.json({ success: true, data: results });
  });
});

// =============================================
//  OBTENER PROMOCIÓN POR CÓDIGO
// =============================================
router.get("/codigo/:codigo", (req, res) => {
  const { codigo } = req.params;

  const sql = `
    SELECT 
      p.ID_Promocion,
      p.Nombre,
      p.Descripcion,
      p.Tipo,
      p.Valor,
      p.Codigo,
      p.ID_Producto,
      pr.Nombre_producto as Producto_Nombre,
      p.Minimo_Compra,
      p.Fecha_Inicio,
      p.Fecha_Fin,
      p.Stock_Limite,
      p.Usos_Actuales
    FROM promociones p
    LEFT JOIN producto pr ON p.ID_Producto = pr.ID_Producto
    WHERE p.Codigo = ? 
      AND p.Estado = 1 
      AND p.Fecha_Inicio <= NOW() 
      AND p.Fecha_Fin >= NOW()
      AND (p.Stock_Limite IS NULL OR p.Usos_Actuales < p.Stock_Limite)
  `;

  db.query(sql, [codigo], (err, results) => {
    if (err) {
      console.error("Error al verificar código:", err);
      return res.status(500).json({ success: false, message: "Error al verificar código" });
    }

    if (results.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: "Código inválido o promoción expirada" 
      });
    }

    res.json({ success: true, data: results[0] });
  });
});

// =============================================
//  CREAR PROMOCIÓN (Admin)
// =============================================
router.post("/admin/crear", verificarToken, verificarAdmin, (req, res) => {
  const { 
    Nombre, 
    Descripcion, 
    Tipo, 
    Valor, 
    Codigo, 
    ID_Producto, 
    Minimo_Compra,
    Fecha_Inicio, 
    Fecha_Fin, 
    Stock_Limite 
  } = req.body;

  if (!Nombre || !Tipo || !Fecha_Inicio || !Fecha_Fin) {
    return res.status(400).json({ 
      success: false, 
      message: "Nombre, Tipo, Fecha_Inicio y Fecha_Fin son obligatorios" 
    });
  }

  const tiposValidos = ['descuento_porcentaje', 'descuento_fijo', '2x1', 'puntos_dobles', 'combo'];
  if (!tiposValidos.includes(Tipo)) {
    return res.status(400).json({ 
      success: false, 
      message: `Tipo no válido. Tipos permitidos: ${tiposValidos.join(', ')}` 
    });
  }

  if (ID_Producto) {
    const checkProductoSql = "SELECT ID_Producto FROM producto WHERE ID_Producto = ?";
    db.query(checkProductoSql, [ID_Producto], (err, result) => {
      if (err || result.length === 0) {
        return res.status(400).json({ 
          success: false, 
          message: "El producto especificado no existe" 
        });
      }
    });
  }

  const sql = `
    INSERT INTO promociones 
    (Nombre, Descripcion, Tipo, Valor, Codigo, ID_Producto, Minimo_Compra, Fecha_Inicio, Fecha_Fin, Stock_Limite, Estado)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `;

  db.query(
    sql,
    [
      Nombre, 
      Descripcion || null, 
      Tipo, 
      Valor || null, 
      Codigo || null, 
      ID_Producto || null, 
      Minimo_Compra || null, 
      Fecha_Inicio, 
      Fecha_Fin, 
      Stock_Limite || null
    ],
    (err, result) => {
      if (err) {
        console.error("Error al crear promoción:", err);
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(400).json({ 
            success: false, 
            message: "El código de promoción ya existe" 
          });
        }
        return res.status(500).json({ 
          success: false, 
          message: "Error al crear la promoción" 
        });
      }

      res.json({
        success: true,
        message: "Promoción creada correctamente",
        ID_Promocion: result.insertId
      });
    }
  );
});

// =============================================
//  ACTUALIZAR PROMOCIÓN (Admin)
// =============================================
router.put("/admin/actualizar/:id", verificarToken, verificarAdmin, (req, res) => {
  const { id } = req.params;
  const { 
    Nombre, 
    Descripcion, 
    Tipo, 
    Valor, 
    Codigo, 
    ID_Producto, 
    Minimo_Compra,
    Fecha_Inicio, 
    Fecha_Fin, 
    Stock_Limite,
    Estado 
  } = req.body;

  const checkSql = "SELECT ID_Promocion FROM promociones WHERE ID_Promocion = ?";
  db.query(checkSql, [id], (err, result) => {
    if (err || result.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: "Promoción no encontrada" 
      });
    }

    const sql = `
      UPDATE promociones 
      SET 
        Nombre = ?,
        Descripcion = ?,
        Tipo = ?,
        Valor = ?,
        Codigo = ?,
        ID_Producto = ?,
        Minimo_Compra = ?,
        Fecha_Inicio = ?,
        Fecha_Fin = ?,
        Stock_Limite = ?,
        Estado = ?
      WHERE ID_Promocion = ?
    `;

    db.query(
      sql,
      [
        Nombre, 
        Descripcion, 
        Tipo, 
        Valor, 
        Codigo, 
        ID_Producto || null, 
        Minimo_Compra || null, 
        Fecha_Inicio, 
        Fecha_Fin, 
        Stock_Limite || null, 
        Estado || 1, 
        id
      ],
      (err) => {
        if (err) {
          console.error("Error al actualizar promoción:", err);
          if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ 
              success: false, 
              message: "El código de promoción ya existe" 
            });
          }
          return res.status(500).json({ 
            success: false, 
            message: "Error al actualizar la promoción" 
          });
        }

        res.json({
          success: true,
          message: "Promoción actualizada correctamente"
        });
      }
    );
  });
});

// =============================================
//  ELIMINAR PROMOCIÓN (Admin)
// =============================================
router.delete("/admin/eliminar/:id", verificarToken, verificarAdmin, (req, res) => {
  const { id } = req.params;

  const sql = "DELETE FROM promociones WHERE ID_Promocion = ?";
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error al eliminar promoción:", err);
      return res.status(500).json({ 
        success: false, 
        message: "Error al eliminar la promoción" 
      });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ 
        success: false, 
        message: "Promoción no encontrada" 
      });
    }

    res.json({
      success: true,
      message: "Promoción eliminada correctamente"
    });
  });
});

// =============================================
//  APLICAR PROMOCIÓN (SIN ENVÍO)
// =============================================
router.post("/aplicar", verificarToken, (req, res) => {
  const { codigo, subtotal, items } = req.body;

  if (!codigo) {
    return res.status(400).json({ 
      success: false, 
      message: "Código de promoción requerido" 
    });
  }

  // Buscar la promoción
  const sql = `
    SELECT * FROM promociones 
    WHERE Codigo = ? 
      AND Estado = 1 
      AND Fecha_Inicio <= NOW() 
      AND Fecha_Fin >= NOW()
      AND (Stock_Limite IS NULL OR Usos_Actuales < Stock_Limite)
  `;

  db.query(sql, [codigo], (err, results) => {
    if (err) {
      console.error("Error al validar código:", err);
      return res.status(500).json({ 
        success: false, 
        message: "Error al validar código" 
      });
    }

    if (results.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: "Código inválido o promoción expirada" 
      });
    }

    const promocion = results[0];
    let descuento = 0;
    let mensaje = "";

    // Verificar monto mínimo de compra
    if (promocion.Minimo_Compra && subtotal < promocion.Minimo_Compra) {
      return res.status(400).json({
        success: false,
        message: `El pedido debe ser mayor a $${promocion.Minimo_Compra.toLocaleString()} para aplicar esta promoción`
      });
    }

    switch (promocion.Tipo) {
      case 'descuento_porcentaje':
        if (promocion.ID_Producto) {
          // Descuento en producto específico
          const item = items.find(i => i.ID_Producto === promocion.ID_Producto);
          if (item) {
            const precioUnitario = item.PrecioUnitario || item.Precio;
            descuento = precioUnitario * item.Cantidad * (promocion.Valor / 100);
            mensaje = `✅ Descuento del ${promocion.Valor}% aplicado a "${item.Nombre_producto}"`;
          } else {
            return res.status(400).json({
              success: false,
              message: `El producto "${promocion.Nombre}" no está en el carrito`
            });
          }
        } else {
          descuento = subtotal * (promocion.Valor / 100);
          mensaje = `✅ Descuento del ${promocion.Valor}% aplicado al total`;
        }
        break;

      case 'descuento_fijo':
        descuento = promocion.Valor;
        mensaje = `✅ Descuento de $${promocion.Valor.toLocaleString()} aplicado`;
        break;

      case '2x1':
        if (promocion.ID_Producto) {
          const item = items.find(i => i.ID_Producto === promocion.ID_Producto);
          if (item && item.Cantidad >= 2) {
            const precioUnitario = item.PrecioUnitario || item.Precio;
            const productosGratis = Math.floor(item.Cantidad / 2);
            descuento = productosGratis * precioUnitario;
            mensaje = `✅ 2x1 aplicado: ${productosGratis} producto(s) gratis`;
          } else {
            return res.status(400).json({
              success: false,
              message: `Necesitas al menos 2 unidades para aplicar 2x1 en "${promocion.Nombre}"`
            });
          }
        } else {
          return res.status(400).json({
            success: false,
            message: "La promoción 2x1 requiere un producto específico"
          });
        }
        break;

      case 'puntos_dobles':
        mensaje = "✅ Puntos dobles acumulados por esta compra";
        descuento = 0;
        break;

      case 'combo':
        if (promocion.ID_Producto) {
          const item = items.find(i => i.ID_Producto === promocion.ID_Producto);
          if (item) {
            const precioUnitario = item.PrecioUnitario || item.Precio;
            descuento = precioUnitario * item.Cantidad * (promocion.Valor / 100);
            mensaje = `✅ Descuento combo del ${promocion.Valor}% aplicado`;
          } else {
            mensaje = "✅ Promoción combo disponible";
            descuento = 0;
          }
        } else {
          descuento = subtotal * (promocion.Valor / 100);
          mensaje = `✅ Descuento combo del ${promocion.Valor}% aplicado al total`;
        }
        break;

      default:
        return res.status(400).json({
          success: false,
          message: "Tipo de promoción no válido"
        });
    }

    // Registrar el uso de la promoción
    if (descuento > 0 || promocion.Tipo === 'puntos_dobles') {
      const updateUsoSql = "UPDATE promociones SET Usos_Actuales = Usos_Actuales + 1 WHERE ID_Promocion = ?";
      db.query(updateUsoSql, [promocion.ID_Promocion], (err) => {
        if (err) {
          console.error("Error al actualizar usos:", err);
        }
      });
    }

    res.json({
      success: true,
      data: {
        descuento: parseFloat(descuento.toFixed(2)),
        total: parseFloat((subtotal - descuento).toFixed(2)),
        mensaje: mensaje,
        promocion: {
          ID_Promocion: promocion.ID_Promocion,
          Nombre: promocion.Nombre,
          Tipo: promocion.Tipo,
          Codigo: promocion.Codigo
        }
      }
    });
  });
});

module.exports = router;