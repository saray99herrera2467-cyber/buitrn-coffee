// utils/emailService.js
const Brevo = require('@getbrevo/brevo');

const defaultClient = Brevo.ApiClient.instance;
const apiKey = defaultClient.authentications['api-key'];
apiKey.apiKey = process.env.BREVO_API_KEY;

const apiInstance = new Brevo.TransactionalEmailsApi();

// =============================================
// FUNCIÓN PRINCIPAL PARA ENVIAR CORREOS
// =============================================
const enviarCorreo = async (email, nombre, asunto, contenidoHtml) => {
    if (!email || !email.includes('@')) {
        console.error(`❌ Email inválido: ${email}`);
        return false;
    }

    if (!process.env.BREVO_API_KEY) {
        console.error('❌ BREVO_API_KEY no está configurada en .env');
        return false;
    }

    try {
        const sendSmtpEmail = new Brevo.SendSmtpEmail();
        sendSmtpEmail.subject = asunto;
        sendSmtpEmail.to = [{ 
            email: email, 
            name: nombre || 'Cliente' 
        }];
        sendSmtpEmail.htmlContent = contenidoHtml;
        sendSmtpEmail.sender = { 
            name: "Buitrón Coffee", 
            email: process.env.EMAIL_FROM || "no-reply@buitroncoffee.com"
        };
        sendSmtpEmail.replyTo = {
            email: process.env.EMAIL_FROM || "no-reply@buitroncoffee.com",
            name: "Buitrón Coffee"
        };

        const response = await apiInstance.sendTransacEmail(sendSmtpEmail);
        console.log(`📧 Correo enviado a ${email}`);
        return true;
        
    } catch (error) {
        console.error(`❌ Error enviando correo a ${email}:`);
        
        if (error.response) {
            console.error(`📌 Status: ${error.response.status}`);
            const body = error.response.body || error.response.data || error.response;
            console.error(`📌 Detalle:`, body.message || body);
        } else {
            console.error(`📌 Error:`, error.message);
        }
        
        return false;
    }
};

// =============================================
// 1. CORREO DE BIENVENIDA
// =============================================
const enviarBienvenida = async (email, nombre) => {
    const html = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f5f0; border-radius: 20px; overflow: hidden;">
            <div style="background: linear-gradient(135deg, #c0392b 0%, #8e2e23 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0; font-size: 28px;">☕ Buitrón Coffee</h1>
                <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0;">El mejor café artesanal de Colombia</p>
            </div>
            <div style="padding: 30px; background: white;">
                <h2 style="color: #2c3e50; margin-top: 0;">¡Bienvenido, ${nombre || 'Cliente'}! ✨</h2>
                <p style="color: #555; line-height: 1.6;">Gracias por formar parte de nuestra comunidad cafetera.</p>
                <div style="background: #fdf2e9; padding: 20px; border-radius: 12px; margin: 20px 0; text-align: center;">
                    <p style="margin: 0; color: #c0392b; font-weight: bold;">🎉 Agradecemos mucho tu interés en nuestro café</p>
                </div>
                <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/catalogo" style="display: inline-block; background: #c0392b; color: white; padding: 12px 30px; text-decoration: none; border-radius: 30px; margin-top: 20px;">Explorar productos →</a>
            </div>
            <div style="background: #2c3e50; padding: 20px; text-align: center;">
                <p style="color: #ecf0f1; margin: 0;">© ${new Date().getFullYear()} Buitrón Coffee</p>
            </div>
        </div>
    `;
    return enviarCorreo(email, nombre, "¡Bienvenid@ a Buitrón Coffee! ☕", html);
};

// =============================================
// 2. CORREO DE RECUPERACIÓN DE CONTRASEÑA
// =============================================
const enviarRecuperacionContrasena = async (email, nombre, codigo) => {
    const html = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 550px; margin: 0 auto; background: #f9f5f0; border-radius: 20px; overflow: hidden;">
            <div style="background: linear-gradient(135deg, #c0392b 0%, #8e2e23 100%); padding: 25px; text-align: center;">
                <h1 style="color: white; margin: 0;">☕ Buitrón Coffee</h1>
                <p style="color: rgba(255,255,255,0.9); margin: 8px 0 0;">Recuperación de contraseña</p>
            </div>
            <div style="padding: 30px; background: white;">
                <h2 style="color: #2c3e50; margin-top: 0;">Hola, ${nombre || 'Cliente'}</h2>
                <p style="color: #555; line-height: 1.6;">Hemos recibido una solicitud para restablecer tu contraseña.</p>
                <div style="background: #fdf2e9; padding: 20px; border-radius: 12px; margin: 25px 0; text-align: center;">
                    <p style="margin: 0 0 10px; color: #2c3e50; font-weight: bold;">Tu código es:</p>
                    <p style="margin: 0; font-size: 32px; font-weight: bold; color: #c0392b; letter-spacing: 5px;">${codigo}</p>
                </div>
                <div style="background: #fff3e0; padding: 15px; border-radius: 12px; margin: 20px 0;">
                    <p style="margin: 0; color: #e67e22;">⏳ Este código expirará en <strong>5 minutos</strong>.</p>
                </div>
                <p style="color: #555;">Si no solicitaste esto, ignora el mensaje.</p>
            </div>
            <div style="background: #2c3e50; padding: 15px; text-align: center;">
                <p style="color: #ecf0f1; margin: 0;">© ${new Date().getFullYear()} Buitrón Coffee</p>
            </div>
        </div>
    `;
    return enviarCorreo(email, nombre, "🔐 Recuperación de contraseña - Buitrón Coffee", html);
};

// =============================================
// 3. CORREO DE CONFIRMACIÓN DE PQRS
// =============================================
const enviarConfirmacionPQRS = async (email, nombre, codigoReferencia, tipo) => {
    const tipos = {
        pregunta: 'Pregunta',
        queja: 'Queja',
        reclamo: 'Reclamo',
        sugerencia: 'Sugerencia',
        felicitacion: 'Felicitación'
    };
    const html = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f5f0; border-radius: 20px; overflow: hidden;">
            <div style="background: linear-gradient(135deg, #c0392b 0%, #8e2e23 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0;">☕ Buitrón Coffee</h1>
                <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0;">PQRS</p>
            </div>
            <div style="padding: 30px; background: white;">
                <h2 style="color: #2c3e50;">¡Hemos recibido tu ${tipos[tipo] || tipo}! 📋</h2>
                <p>Hola, <strong>${nombre || 'Cliente'}</strong>. Gracias por comunicarte con nosotros.</p>
                <div style="background: #fdf2e9; padding: 20px; border-radius: 12px; margin: 20px 0;">
                    <p><strong>Código de referencia:</strong></p>
                    <p style="font-size: 24px; font-weight: bold; color: #c0392b;">${codigoReferencia}</p>
                </div>
                <p>⏳ Tu solicitud ha sido enviada. Te responderemos a la brevedad.</p>
            </div>
            <div style="background: #2c3e50; padding: 20px; text-align: center;">
                <p style="color: #ecf0f1;">© ${new Date().getFullYear()} Buitrón Coffee</p>
            </div>
        </div>
    `;
    return enviarCorreo(email, nombre, `Hemos recibido tu ${tipos[tipo] || tipo}`, html);
};

// =============================================
// 4. CORREO DE RESPUESTA A PQRS
// =============================================
const enviarRespuestaPQRS = async (email, nombre, respuesta, codigoReferencia) => {
    const html = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f5f0; border-radius: 20px; overflow: hidden;">
            <div style="background: linear-gradient(135deg, #c0392b 0%, #8e2e23 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0;">☕ Buitrón Coffee</h1>
                <p style="color: rgba(255,255,255,0.9);">Respuesta a tu PQRS</p>
            </div>
            <div style="padding: 30px; background: white;">
                <h2>¡El administrador te ha respondido!</h2>
                <p>Hola, <strong>${nombre || 'Cliente'}</strong>. Tu solicitud ha sido revisada.</p>
                <div style="background: #fdf2e9; padding: 20px; border-radius: 12px; margin: 20px 0;">
                    <p><strong>Código:</strong> ${codigoReferencia}</p>
                    <p><strong>Respuesta:</strong></p>
                    <p style="padding: 15px; background: white; border-radius: 10px;">${respuesta}</p>
                </div>
                <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/consultarpqrs" style="display: inline-block; background: #c0392b; color: white; padding: 12px 30px; text-decoration: none; border-radius: 30px;">Consultar mi PQRS →</a>
            </div>
            <div style="background: #2c3e50; padding: 20px; text-align: center;">
                <p style="color: #ecf0f1;">© ${new Date().getFullYear()} Buitrón Coffee</p>
            </div>
        </div>
    `;
    return enviarCorreo(email, nombre, `Respuesta a tu PQRS #${codigoReferencia}`, html);
};

// =============================================
// 5. CORREO DE CONFIRMACIÓN DE PEDIDO
// =============================================
const enviarConfirmacionPedido = async (email, nombre, pedidoId, total, fechaLimite) => {
    const html = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f5f0; border-radius: 20px; overflow: hidden;">
            <div style="background: linear-gradient(135deg, #c0392b 0%, #8e2e23 100%); padding: 30px; text-align: center;">
                <h1 style="color: white;">☕ Buitrón Coffee</h1>
                <p style="color: white;">Confirmación de Pedido</p>
            </div>
            <div style="padding: 30px; background: white;">
                <h2>¡Pedido confirmado, ${nombre || 'Cliente'}! 🎉</h2>
                <div style="background: #fdf2e9; padding: 20px; border-radius: 12px; margin: 20px 0;">
                    <p><strong>Pedido #:</strong> ${pedidoId}</p>
                    <p><strong>Total a pagar:</strong> $${total.toLocaleString()}</p>
                    <p><strong>Fecha límite:</strong> ${fechaLimite}</p>
                </div>
                <div style="background: #f0fdf4; padding: 20px; border-radius: 12px;">
                    <p>📍 Dirígete a nuestro punto físico para recibir tu pedido</p>
                    <p><strong>Calle 123 # 45-67, Bogotá</strong></p>
                </div>
                <div style="background: #fff3e0; padding: 15px; border-radius: 12px; margin-top: 20px;">
                    <p>⏳ Recuerda que tu pedido tiene fecha límite para ser pagado</p>
                </div>
            </div>
            <div style="background: #2c3e50; padding: 20px; text-align: center;">
                <p style="color: #ecf0f1;">© ${new Date().getFullYear()} Buitrón Coffee</p>
            </div>
        </div>
    `;
    return enviarCorreo(email, nombre, `Pedido confirmado #${pedidoId}`, html);
};

// =============================================
// 6. CORREO DE CÓDIGO DE VERIFICACIÓN (NUEVO)
// =============================================
const enviarCodigoVerificacion = async (email, codigo) => {
    const html = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f5f0; border-radius: 20px; overflow: hidden;">
            <div style="background: linear-gradient(135deg, #c0392b 0%, #8e2e23 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0;">☕ Buitrón Coffee</h1>
                <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0;">Verificación de Correo</p>
            </div>
            <div style="padding: 30px; background: white;">
                <h2 style="color: #2c3e50; margin-top: 0;">¡Verifica tu correo! ✉️</h2>
                <p style="color: #555; line-height: 1.6;">Hemos recibido tu solicitud de registro en <strong>Buitrón Coffee</strong>.</p>
                <p style="color: #555; line-height: 1.6;">Para confirmar que este correo es válido, ingresa el siguiente código:</p>
                <div style="background: #fdf2e9; padding: 25px; border-radius: 12px; margin: 25px 0; text-align: center; border: 2px dashed #c0392b;">
                    <p style="margin: 0; font-size: 14px; color: #6c757d;">Tu código de verificación es:</p>
                    <p style="margin: 10px 0 0; font-size: 42px; font-weight: bold; color: #c0392b; letter-spacing: 8px;">${codigo}</p>
                </div>
                <div style="background: #fff3e0; padding: 15px; border-radius: 12px; margin: 20px 0;">
                    <p style="margin: 0; color: #e67e22;">⏳ Este código expirará en <strong>10 minutos</strong>.</p>
                </div>
                <p style="color: #555; font-size: 14px;">Si no solicitaste esto, ignora este mensaje.</p>
                <hr style="border: none; border-top: 1px solid #e9ecef; margin: 20px 0;">
                <p style="color: #888; font-size: 12px;">Este es un mensaje automático. No respondas a este correo.</p>
            </div>
            <div style="background: #2c3e50; padding: 20px; text-align: center;">
                <p style="color: #ecf0f1; margin: 0;">© ${new Date().getFullYear()} Buitrón Coffee - El mejor café artesanal de Colombia</p>
            </div>
        </div>
    `;
    return enviarCorreo(email, 'Cliente', "🔐 Código de verificación - Buitrón Coffee", html);
};

// =============================================
// 7. ALERTA DE STOCK BAJO PARA ADMIN
// =============================================
const enviarCorreoAlertaStock = async (email, nombre, productosStockBajo, htmlContent) => {
    const asunto = `⚠️ ALERTA: ${productosStockBajo.length} productos con stock bajo`;
    
    if (!htmlContent) {
        htmlContent = `
            <div style="font-family: Arial, sans-serif; max-width: 600px;">
                <div style="background: #e67e22; padding: 20px; text-align: center;">
                    <h1 style="color: white;">⚠️ Alerta de Stock Bajo</h1>
                </div>
                <div style="padding: 20px; border: 1px solid #ddd;">
                    <h2>Hola, ${nombre || 'Administrador'}</h2>
                    <p>Los siguientes productos tienen stock bajo:</p>
                    <ul>
                        ${productosStockBajo.map(p => `
                            <li><strong>${p.Nombre_producto}</strong> - Stock: ${p.Stock} unidades (${p.nivel_stock || 'Bajo'})</li>
                        `).join('')}
                    </ul>
                    <p>Por favor, revisa el inventario y realiza los pedidos necesarios.</p>
                    <hr>
                    <p style="color: #888; font-size: 12px;">Este es un mensaje automático del sistema Buitrón Coffee.</p>
                </div>
            </div>
        `;
    }
    
    return enviarCorreo(email, nombre, asunto, htmlContent);
};

module.exports = {
    enviarBienvenida,
    enviarRecuperacionContrasena,
    enviarConfirmacionPQRS,
    enviarRespuestaPQRS,
    enviarConfirmacionPedido,
    enviarCodigoVerificacion,
    enviarCorreoAlertaStock
};